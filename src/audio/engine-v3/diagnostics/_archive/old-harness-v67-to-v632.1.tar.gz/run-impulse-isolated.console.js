// run-impulse-isolated.console.js v6.6 — Gate 3, ИЗОЛИРОВАННЫЙ AudioContext
// Вердикт Опуса (Round 21e, Q7 ОДОБРЕН):
//   1. numberOfOutputs: 1 + outputChannelCount: [1] — mono-нода (vendor при numberOfInputs:0 может оставить 2 канала)
//   2. Mono импульс — отдельный корректный channel buffer ([[Float32Array]])
//   3. splitComputation: true — ТОЛЬКО зеркало production (StretchInstance.ts:57-61), без изменения DSP
//   4. ctx.close() ОБЯЗАТЕЛЕН в finally
// Критерии приёмки (Опуса):
//   - maxInputSamplesEnd ≤ 1.5s (валидность теста)
//   - audioBufferIndex_max ≥ 1 (импульс реально востребован)
//   - Пик ~2646 (60ms) с измеренным индексом → Gate 3 PASS
// Отличие от v6.5: НЕ трогаем p._ctx и inst._node приложения — свой ctx + своя vendor-нода.

;(async () => {
  const result = { stage: 'running', errors: [] }
  window.__impulseResult = result

  // ── 1. Импорт vendor через Vite dev (приложение уже открыто → Vite активен) ──
  //    base '/beLive/' (vite.config.ts:65) — модуль доступен по /beLive/src/...
  let SignalsmithStretch
  const vendorPaths = [
    '/beLive/src/audio/engine-v3/vendor/SignalsmithStretch.mjs',
    '/src/audio/engine-v3/vendor/SignalsmithStretch.mjs',   // fallback (base '/')
  ]
  for (const p of vendorPaths) {
    try {
      const mod = await import(p)
      SignalsmithStretch = mod.default || mod
      result.vendorLoaded = true
      result.vendorPath = p
      console.log('[ImpulseTest-v6.6] vendor loaded from:', p, '→', typeof SignalsmithStretch)
      break
    } catch (e) {
      result.errors.push('vendor import ' + p + ': ' + e.message)
    }
  }
  if (!SignalsmithStretch) {
    result.stage = 'error'
    window.__impulseResult = result
    return JSON.stringify(result)
  }

  // ── 2. RPC helper (addEventListener — НЕ перезаписываем vendor-овский onmessage) ──
  const rpc = (n, method, args, timeoutMs = 5000) => new Promise(resolve => {
    if (!n || !n.port) return resolve(null)
    const id = Math.random().toString(36).slice(2)
    const timer = setTimeout(() => { try { n.port.removeEventListener('message', h) } catch (e) {}; resolve(null) }, timeoutMs)
    const h = (e) => { const [mid, data] = e.data; if (mid === id) { clearTimeout(timer); try { n.port.removeEventListener('message', h) } catch (e) {}; resolve(data) } }
    n.port.addEventListener('message', h)
    n.port.postMessage([id, method, ...args])
  })

  // ── 3. Capture worklet (blob, как v6.5: port.start() + passthrough + кольцевой буфер) ──
  const CAPTURE_NAME = 'belive-capture-processor-v66'
  const code = [
    'var CAPTURE_NAME="belive-capture-processor-v66";',
    'class CaptureProcessor extends AudioWorkletProcessor{',
      'constructor(options){super(options);',
        'var size=(options&&options.processorOptions&&options.processorOptions.bufferSize)||44100;',
        'this._bufferSize=size;this._buffer=new Float32Array(size);this._writeIndex=0;this._processCount=0;',
        'this.port.onmessage=(e)=>{',
          'var d=e.data,id=d[0],method=d[1],args=d.slice(2);',
          'switch(method){',
            'case"ping":this.port.postMessage([id,"pong"]);break;',
            'case"getStats":this.port.postMessage([id,{processCount:this._processCount,writeIndex:this._writeIndex,bufferSize:this._bufferSize}]);break;',
            'case"read":{',
              'var len=args[0]!==undefined?args[0]:this._bufferSize;',
              'var safeLen=Math.min(len,this._bufferSize);',
              'var res=new Float32Array(safeLen);',
              'var wi=this._writeIndex,bs=this._bufferSize,buf=this._buffer;',
              'for(var i=0;i<safeLen;i++){res[i]=buf[(wi-safeLen+i+bs)%bs]}',
              'this.port.postMessage([id,res]);break;',
            '}',
            'case"clear":{this._buffer.fill(0);this._writeIndex=0;this.port.postMessage([id,true]);break;}',
            'default:this.port.postMessage([id,null])',
          '}',
        '}',
      '}',
      'process(inputs,outputs){',
        'this._processCount++;',
        'var input=inputs[0],output=outputs[0];',
        'if(output&&output.length>0&&output[0]){',
          'if(input&&input.length>0&&input[0]){',
            'for(var c=0;c<output.length&&c<input.length;c++){output[c].set(input[c])}',
          '}else{for(var c=0;c<output.length;c++){output[c].fill(0)}}',
        '}',
        'if(!input||input.length===0||input[0].length===0)return true;',
        'var ch=input[0],len=ch.length,buf=this._buffer,bs=this._bufferSize,wi=this._writeIndex;',
        'for(var i=0;i<len;i++){buf[wi]=ch[i];wi=(wi+1)%bs}this._writeIndex=wi;',
        'return true',
      '}',
    '}',
    'registerProcessor(CAPTURE_NAME,CaptureProcessor);',
  ].join('')

  let ctx = null
  try {
    // ── 4. Изолированный AudioContext (чистый timeMap, currentTime=0) ──
    ctx = new AudioContext({ sampleRate: 44100 })
    result.ctxState = ctx.state
    if (ctx.state === 'suspended') {
      try { await ctx.resume() } catch (e) { result.errors.push('ctx.resume: ' + e.message) }
      result.ctxState = ctx.state
    }
    const sr = ctx.sampleRate
    result.sampleRate = sr
    console.log('[ImpulseTest-v6.6] isolated ctx:', ctx.state, 'sr:', sr)

    // ── 5. Register capture на ИЗОЛИРОВАННОМ ctx ──
    await ctx.audioWorklet.addModule(URL.createObjectURL(new Blob([code], { type: 'text/javascript' })))
    result.captureModuleLoaded = true

    // ── 6. Vendor-нода: mono (поправка Опуса #1), зеркало production (поправка #3) ──
    const node = await SignalsmithStretch(ctx, {
      numberOfInputs: 0,
      numberOfOutputs: 1,
      outputChannelCount: [1],
    })
    await (node).configure({ blockMs: 40, intervalMs: 20, splitComputation: true })
    result.configured = true

    const latency = await node.latency()
    const latencySamples = Math.round(latency * sr)
    result.latencySamples = latencySamples
    result.latencyMs = Number((latency * 1000).toFixed(2))
    console.log('[ImpulseTest-v6.6] vendor node ready, latency:', result.latencyMs, 'ms')

    // ── 7. Цепь: node → capture → silentGain(0.000001) → destination ──
    const capBufferSize = Math.max(latencySamples * 4, 44100)
    const captureNode = new AudioWorkletNode(ctx, CAPTURE_NAME, {
      numberOfInputs: 1,
      numberOfOutputs: 1,
      processorOptions: { bufferSize: capBufferSize },
    })
    // v6.5 урок: явный port.start() — иначе backward-канал молчит
    try { captureNode.port.start() } catch (e) { result.errors.push('port.start: ' + e.message) }
    captureNode.port.onmessage = (e) => {
      const d = e?.data
      if (Array.isArray(d) && d[1] === 'pong') result._captureOnmessageSeen = true
    }
    captureNode.addEventListener('processorerror', (e) => {
      result.captureProcessorError = String(e?.message ?? e)
      console.log('[ImpulseTest-v6.6] CAPTURE processorerror:', e?.message ?? e)
    })
    const silentGain = ctx.createGain()
    silentGain.gain.value = 0.000001   // вердикт Опуса (079): НЕ 0
    node.connect(captureNode)
    captureNode.connect(silentGain)
    silentGain.connect(ctx.destination)
    result.chainConnected = true
    console.log('[ImpulseTest-v6.6] chain: node(mono) → capture → silentGain → destination')
    await new Promise(r => setTimeout(r, 500))

    // ── 8. Инструментация + ping живости capture ──
    await rpc(node, 'setInstrumentation', [true])
    result.capturePing = await rpc(captureNode, 'ping', [], 2000)

    // ── 9. Mono импульс: отдельный корректный channel buffer (поправка Опуса #2) ──
    const bufLen = Math.ceil(sr * 0.5)
    const impulseBuf = new Float32Array(bufLen)
    impulseBuf[0] = 1.0
    const addRes = await rpc(node, 'addBuffers', [[impulseBuf]])
    if (addRes === null) result.errors.push('addBuffers timeout')
    result.addBuffersOk = addRes !== null

    // ── 10. clear ПЕРЕД start → пик будет на позиции ≈ latencySamples от начала записи ──
    await rpc(captureNode, 'clear', [], 2000)
    const startRes = await rpc(node, 'start', [{ input: 0, rate: 1.0, active: true }])
    if (startRes === null) result.errors.push('start timeout')
    result.startOk = startRes !== null

    // ── 11. Ждём проход импульса: latency(60ms) + импульс(500ms) + запас → 0.8с ──
    //      Запись с clear: ~0.85с < bufferSize 1с → не обернётся, пик в буфере
    await new Promise(r => setTimeout(r, 800))

    // ── 12. stats + read ВСЕГО буфера (иначе начало записи с пиком потеряется) ──
    result.captureStats = await rpc(captureNode, 'getStats', [], 2000)
    const captured = await rpc(captureNode, 'read', [capBufferSize])
    result.capturedLen = captured && captured.length ? captured.length : 0
    result._onmessageSeen = !!result._captureOnmessageSeen

    // ── 13. Анализ ──
    if (!captured || captured.length === 0) {
      result.stage = 'no-capture'
      result.error = 'capture empty/timeout'
    } else {
      let peakIndex = -1, peakAmplitude = 0, outputSum = 0
      for (let i = 0; i < captured.length; i++) {
        const abs = Math.abs(captured[i])
        outputSum += abs
        if (abs > peakAmplitude) { peakAmplitude = abs; peakIndex = i }
      }
      result.peakIndex = peakIndex
      result.peakAmplitude = Number(peakAmplitude.toFixed(6))
      result.outputSum = Number(outputSum.toFixed(4))

      // Позиция пика в потоке записи (от clear) — учитываем окно read
      if (peakIndex >= 0 && result.captureStats) {
        const wi = result.captureStats.writeIndex
        const bs = result.captureStats.bufferSize
        const peakWriteIndex = (wi - captured.length + peakIndex + bs) % bs
        result.peakWriteIndex = peakWriteIndex
        result.measuredDelaySamples = peakWriteIndex
        result.measuredDelayMs = Number(((peakWriteIndex / sr) * 1000).toFixed(2))
        result.sampleShift = peakWriteIndex - latencySamples
      }

      // ── 14. Валидация (критерии Опуса) ──
      result.instrumentation = await rpc(node, 'getInstrumentMetrics', [])
      const ins = result.instrumentation || {}
      const maxSec = (ins.inputSamplesEnd?.max ?? 0) / sr
      const bufIdxMax = ins.audioBufferIndex_max ?? 0
      const validation = {
        inputSamplesEndMaxSec: Number(maxSec.toFixed(3)),
        valid_leq_1_5s: maxSec <= 1.5,
        audioBufferIndexMax: bufIdxMax,
        valid_ge_1: bufIdxMax >= 1,
        audioBuffersStart: ins.audioBuffersStart ?? 0,
        audioBuffersEnd: ins.audioBuffersEnd ?? 0,
        audioBuffersCount: ins.audioBuffersCount ?? 0,
      }
      result.validation = validation

      const pass = peakIndex > 0 && peakAmplitude > 0.1 &&
        Math.abs(result.sampleShift ?? Infinity) <= latencySamples &&
        validation.valid_leq_1_5s && validation.valid_ge_1
      result.gate3 = pass ? 'PASS' : 'FAIL'
      result.gate3Detail = pass
        ? `peak=${result.peakAmplitude} writeIdx=${result.peakWriteIndex} shift=${result.sampleShift} valid=OK`
        : `peak=${result.peakAmplitude} idx=${peakIndex} shift=${result.sampleShift} valid=${JSON.stringify(validation)}`
    }

    result.stage = 'done'
  } catch (e) {
    result.stage = 'error'
    result.error = String(e?.message ?? e)
  } finally {
    window.__impulseResult = result
    console.log('[ImpulseTest-v6.6] ======= RESULT =======')
    console.log(JSON.stringify(result))
    // ctx.close() ОБЯЗАТЕЛЕН (поправка Опуса #4) — как harness.ts:188-192
    try { if (ctx) await ctx.close() } catch (e) { result.errors.push('ctx.close: ' + e.message) }
  }
  return JSON.stringify(result)
})().catch(e => {
  const err = { stage: 'error', error: String(e?.message ?? e) }
  if (window.__impulseResult?.errors?.length) err.errors = window.__impulseResult.errors
  window.__impulseResult = err
  console.log('[ImpulseTest-v6.6] ======= ERROR =======')
  console.log(JSON.stringify(err))
  return JSON.stringify(err)
})
