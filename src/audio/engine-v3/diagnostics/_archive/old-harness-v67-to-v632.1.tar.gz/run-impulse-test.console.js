// run-impulse-test.console.js v6 — Gate 3, по указаниям Опуса (079 Q1)
// Изменения против v5:
//   1. Тайминг ~3с (v5: latency*3000+500 = 180с — баг, latency в секундах)
//   2. processorerror listener на capture-ноду — поймать ошибки ворклета
//   3. ping RPC — проверка живости capture-ворклета
//   4. processCount в capture-ворклете — вызывается ли process() вообще
//   5. silentGain 0 → 0.000001 (Опус: Chrome может не запускать process при нулевом выходе)

;(async () => {
  // ── 0. Ждём pipeline (приложение грузится после navigate) ──
  let p = window.__belive?.pipeline
  const t0 = Date.now()
  while (!p) {
    if (Date.now() - t0 > 45000) return JSON.stringify({ stage: 'timeout', error: 'pipeline not ready in 45s' })
    await new Promise(r => setTimeout(r, 300))
    p = window.__belive?.pipeline
  }

  const ctx = p._ctx
  const pool = p._stretchPool
  const inst = pool.get('vocals') || pool._instances.get(0)
  if (!inst?._node) return JSON.stringify({ stage: 'error', error: 'no instance with _node' })

  const node = inst._node
  const outputGain = inst._outputGain
  const sr = ctx.sampleRate
  const result = { stage: 'running', errors: [] }
  window.__impulseResult = result

  // ── 1. resume ctx (ключевой фикс!) ──
  if (ctx.state !== 'running') {
    try {
      await ctx.resume()
      await new Promise(r => setTimeout(r, 100))
    } catch (e) {
      result.errors.push('ctx.resume: ' + e.message)
    }
  }
  result.ctxState = ctx.state

  const latency = await node.latency()
  const latencySamples = Math.round(latency * sr)
  result.latencySamples = latencySamples
  result.latencyMs = Number((latency * 1000).toFixed(2))

  // ── 2. RPC helper с таймаутом ──
  const rpc = (n, method, args, timeoutMs = 5000) => new Promise(resolve => {
    if (!n || !n.port) return resolve(null)   // v6.1: защита от null-ноды
    const id = Math.random().toString(36).slice(2)
    const timer = setTimeout(() => { try { n.port.removeEventListener('message', h) } catch (e) {}; resolve(null) }, timeoutMs)
    const h = (e) => { const [mid, data] = e.data; if (mid === id) { clearTimeout(timer); try { n.port.removeEventListener('message', h) } catch (e) {}; resolve(data) } }
    n.port.addEventListener('message', h)
    n.port.postMessage([id, method, ...args])
  })

  // ── 3. Register capture worklet (v6.3: console.log диагностика из ворклета) ──
  const CAPTURE_NAME = 'belive-capture-processor-v6'   // уникальное имя — старый v5-модуль не мешает
  if (!ctx.__captureLoadedV6) {
    const code = [
      'var CAPTURE_NAME="belive-capture-processor-v6";',
      'class CaptureProcessor extends AudioWorkletProcessor{',
        'constructor(options){super(options);',
          'console.log("[CAPTURE] constructor called");',   // v6.3: виден в консоли Chrome
          'var size=(options&&options.processorOptions&&options.processorOptions.bufferSize)||44100;',
          'this._bufferSize=size;this._buffer=new Float32Array(size);this._writeIndex=0;this._processCount=0;',
          'this.port.onmessage=(e)=>{',
            'console.log("[CAPTURE] RPC received: "+(e.data&&e.data[1]));',   // v6.4: доходит ли сообщение?
            'var d=e.data,id=d[0],method=d[1],args=d.slice(2);',
            'switch(method){',
              'case"ping":this.port.postMessage([id,"pong"]);break;',
              'case"getStats":this.port.postMessage([id,{processCount:this._processCount,writeIndex:this._writeIndex,bufferSize:this._bufferSize}]);break;',
              'case"read":{',
                'var len=args[0]!==undefined?args[0]:this._bufferSize;',
                'var safeLen=Math.min(len,this._bufferSize);',
                'var res=new Float32Array(safeLen);',
                'var wi=this._writeIndex,bs=this._bufferSize,buf=this._buffer;',
                'for(var i=0;i<safeLen;i++){res[i]=buf[(wi-safeLen+i+bs)%bs]}',
                'this.port.postMessage([id,res]);break;',
              '}',
            'case"clear":{this._buffer.fill(0);this._writeIndex=0;this.port.postMessage([id,true]);break;}',
            'default:this.port.postMessage([id,null])',
          '}',
          'console.log("[CAPTURE] RPC handled: "+method);',   // v6.5: прошёл ли switch до postMessage
          'console.log("[CAPTURE] response posted for: "+method);',   // v6.5: отправили ли ответ
        '}',
      '}',
      'process(inputs,outputs){',
          'this._processCount++;',
          'if(this._processCount===1||this._processCount%100===0){console.log("[CAPTURE] process #"+this._processCount+" input="+(inputs&&inputs[0]&&inputs[0][0]?inputs[0][0].length:0))}',   // v6.3
          'var input=inputs[0],output=outputs[0];',
          'if(output&&output.length>0&&output[0]){',
            'if(input&&input.length>0&&input[0]){',
              'for(var c=0;c<output.length&&c<input.length;c++){output[c].set(input[c])}',
            '}else{for(var c=0;c<output.length;c++){output[c].fill(0)}}',
          '}',
          'if(!input||input.length===0||input[0].length===0)return true;',
          'var ch=input[0],len=ch.length,buf=this._buffer,bs=this._bufferSize,wi=this._writeIndex;',
          'for(var i=0;i<len;i++){buf[wi]=ch[i];wi=(wi+1)%bs}this._writeIndex=wi;',
          'return true',
        '}',
      '}',
      'registerProcessor(CAPTURE_NAME,CaptureProcessor);',   // ; обязательна при join('')
      'console.log("[CAPTURE] worklet module loaded");',   // v6.3
    ].join('')
    try {
      await ctx.audioWorklet.addModule(URL.createObjectURL(new Blob([code], { type: 'text/javascript' })))
      ctx.__captureLoadedV6 = true
      console.log('[ImpulseTest] capture module loaded OK')
    } catch (e) {
      result.errors.push('capture worklet: ' + e.message)
    }
  }

  // ── 4. Цепь: node → capture → silentGain(0.000001) → destination ──
  let captureNode = null
  try {
    captureNode = new AudioWorkletNode(ctx, CAPTURE_NAME, {
      numberOfInputs: 1,
      numberOfOutputs: 1,
      processorOptions: { bufferSize: Math.max(latencySamples * 4, 44100) },
    })
    console.log('[ImpulseTest] capture node created, port:', !!captureNode.port)   // v6.3
    // v6.5: СТАРТ порта — vendor (стр. 568) назначает port.onmessage, что неявно стартует порт.
    // Наша capture-нода создана сами — порт может не принимать ответы, пока не стартован.
    try { captureNode.port.start() } catch (e) { console.log('[ImpulseTest] port.start err:', e?.message ?? e) }
    // v6.5: постоянный слушатель ВСЕХ входящих — увидим, приходят ли ответы ворклета вообще
    captureNode.port.onmessage = (e) => {
      const d = e?.data
      console.log('[ImpulseTest] CAPTURE port onmessage:', Array.isArray(d) ? `[${d[0]?.toString().slice(0,8)}, ${typeof d[1] === 'object' ? JSON.stringify(d[1])?.slice(0,120) : d[1]}]` : String(d)?.slice(0,120))
      if (Array.isArray(d) && d[1] === 'pong') result._captureOnmessageSeen = true
    }
    // v6: processorerror — поймать падение ворклета (конструктор/process)
    captureNode.addEventListener('processorerror', (e) => {
      result.captureProcessorError = String(e?.message ?? e)
      console.log('[ImpulseTest] CAPTURE processorerror:', e?.message ?? e)
    })
    const silentGain = ctx.createGain()
    silentGain.gain.value = 0.000001   // v6: НЕ 0 — Chrome может не запускать process при нулевом выходе (Опус)
    try { node.disconnect(outputGain) } catch (e) { /* ok */ }
    node.connect(captureNode)
    captureNode.connect(silentGain)
    silentGain.connect(ctx.destination)
    result.chainConnected = true
    console.log('[ImpulseTest] chain connected: node → capture → silentGain → destination')
    // v6.3: ждём 500ms — дать Chrome активировать процессор в графе
    await new Promise(r => setTimeout(r, 500))
  } catch (e) {
    result.errors.push('chain: ' + e.message)
  }
  // v6.1: если capture не создался — не продолжаем, показываем причину
  if (!captureNode) {
    result.stage = 'capture-node-failed'
    result.error = 'captureNode is null; errors=' + JSON.stringify(result.errors)
    window.__impulseResult = result
    console.log('[ImpulseTest] ======= RESULT =======')
    console.log(JSON.stringify(result))
    return JSON.stringify(result)
  }

  // ── 5. Инструментируем + очищаем + ping живости capture ──
  try { await rpc(node, 'setInstrumentation', [true]) } catch (e) { result.errors.push('setInstr: ' + e.message) }
  try { await rpc(node, 'dropBuffers', []) } catch (e) { result.errors.push('dropBuffers: ' + e.message) }
  await rpc(captureNode, 'clear', [], 2000)
  result.capturePing = await rpc(captureNode, 'ping', [], 2000)   // v6: 'pong' = capture жив

  // ── 6. Импульс ──
  const bufLen = Math.ceil(sr * 0.5)
  const impulseBuf = new Float32Array(bufLen)
  impulseBuf[0] = 1.0
  const addRes = await rpc(node, 'addBuffers', [[impulseBuf]])
  if (addRes === null) result.errors.push('addBuffers timeout')
  result.addBuffersOk = addRes !== null

  const startRes = await rpc(node, 'start', [{ input: 0, rate: 1.0, active: true }])
  if (startRes === null) result.errors.push('start timeout')
  result.startOk = startRes !== null

  // ── 7. Ждём проход импульса: ~3с (v6: было 180с — баг!) ──
  await new Promise(r => setTimeout(r, 3000))

  // ── 8. v6: stats ДО read — вызывался ли process() capture-ноды? ──
  result.captureStats = await rpc(captureNode, 'getStats', [], 2000)

  // ── 9. Читаем захват ──
  const readLen = Math.ceil(bufLen + latencySamples * 2)
  const captured = await rpc(captureNode, 'read', [readLen])
  result.capturedLen = captured && captured.length ? captured.length : 0
  result._onmessageSeen = !!result._captureOnmessageSeen   // v6.5: видели ли ответ 'pong' через port.onmessage

  // ── 10. Анализ ──
  if (!captured || captured.length === 0) {
    result.stage = 'no-capture'
    result.error = 'capture empty/timeout'
  } else {
    let peakIndex = -1, peakAmplitude = 0, outputSum = 0
    for (let i = 0; i < captured.length; i++) {
      const abs = Math.abs(captured[i])
      outputSum += abs
      if (abs > peakAmplitude) { peakAmplitude = abs; peakIndex = i }
    }
    result.peakIndex = peakIndex
    result.peakAmplitude = Number(peakAmplitude.toFixed(6))
    result.measuredDelaySamples = peakIndex
    result.measuredDelayMs = Number(((peakIndex / sr) * 1000).toFixed(2))
    result.sampleShift = peakIndex - latencySamples
    result.outputSum = Number(outputSum.toFixed(4))
    result.captureLength = captured.length

    const pass = peakIndex > 0 && peakAmplitude > 0.1 && Math.abs(peakIndex - latencySamples) <= latencySamples
    result.gate3 = pass ? 'PASS' : 'FAIL'
    result.gate3Detail = pass
      ? (Math.abs(result.sampleShift) <= 5 ? 'direct-offset CONFIRMED' : `pass, shift=${result.sampleShift}`)
      : `peak=${result.peakAmplitude} idx=${peakIndex} shift=${result.sampleShift}`
  }

  // ── 11. Метрики вендора ──
  result.instrumentation = await rpc(node, 'getInstrumentMetrics', [])

  // ── 12. Cleanup ──
  try {
    if (captureNode) { captureNode.disconnect() }
    try { node.disconnect() } catch (e) {}
    node.connect(outputGain)
  } catch (e) { result.errors.push('cleanup: ' + e.message) }
  try { await rpc(node, 'setInstrumentation', [false]) } catch (e) {}
  try { await rpc(node, 'dropBuffers', []) } catch (e) {}

  result.stage = 'done'
  window.__impulseResult = result
  console.log('[ImpulseTest] ======= RESULT =======')
  console.log(JSON.stringify(result))
  return JSON.stringify(result)
})().catch(e => {
  const err = { stage: 'error', error: String(e?.message ?? e) }
  // v6.1: не теряем накопленные result.errors
  if (window.__impulseResult?.errors?.length) err.errors = window.__impulseResult.errors
  window.__impulseResult = err
  console.log('[ImpulseTest] ======= ERROR =======')
  console.log(JSON.stringify(err))
  return JSON.stringify(err)
})
