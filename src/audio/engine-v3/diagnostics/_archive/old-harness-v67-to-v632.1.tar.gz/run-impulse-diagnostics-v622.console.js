// run-impulse-diagnostics-v622.console.js v6.22 — Gate 3: peak-based onset + atomic readWindow + stimulus-aware peak thresholds
// Авторизация: Опус_4 + Sol_1 (Round 24/25). Без DSP.
// Исправления v6.11: readWindow (атомарное окно [0..writeIndex]), peak-based onset (|peak-latency|≤128), denormal threshold 1e-6

;(async () => {
  const result = { stage: 'running', errors: [], variants: [] }
  window.__impulseResultV622 = result

  // ── 0. Вариант: B | A | C | D | ALL ──
  const VARIANT = (window.__V67_VARIANT || 'ALL').toUpperCase()

  // ── 1. Импорт vendor через Vite dev (base '/beLive/', vite.config.ts:65) ──
  let SignalsmithStretch
  const vendorPaths = [
    '/beLive/src/audio/engine-v3/vendor/SignalsmithStretch.mjs',
    '/src/audio/engine-v3/vendor/SignalsmithStretch.mjs',
  ]
  for (const p of vendorPaths) {
    try {
      const mod = await import(p)
      SignalsmithStretch = mod.default || mod
      result.vendorLoaded = true
      result.vendorPath = p
      console.log('[ImpulseTest-v6.22] vendor loaded from:', p, '→', typeof SignalsmithStretch)
      break
    } catch (e) {
      result.errors.push('vendor import ' + p + ': ' + e.message)
    }
  }
  if (!SignalsmithStretch) {
    result.stage = 'error'
    window.__impulseResultV622 = result
    return JSON.stringify(result)
  }

  // ── 2. RPC helper ──
  const rpc = (n, method, args, timeoutMs = 5000) => new Promise(resolve => {
    if (!n || !n.port) return resolve(null)
    const id = Math.random().toString(36).slice(2)
    const timer = setTimeout(() => { try { n.port.removeEventListener('message', h) } catch (e) {}; resolve(null) }, timeoutMs)
    const h = (e) => { const [mid, data] = e.data; if (mid === id) { clearTimeout(timer); try { n.port.removeEventListener('message', h) } catch (e) {}; resolve(data) } }
    n.port.addEventListener('message', h)
    n.port.postMessage([id, method, ...args])
  })

  // ── 3. Capture worklet (v611: readWindow + denormal threshold 1e-6) ──
  const CAPTURE_NAME = 'belive-capture-processor-v622'
  const code = [
    'var CAPTURE_NAME="belive-capture-processor-v622";',
    'class CaptureProcessor extends AudioWorkletProcessor{',
      'constructor(options){super(options);',
        'var size=(options&&options.processorOptions&&options.processorOptions.bufferSize)||44100;',
        'this._bufferSize=size;this._buffer=new Float32Array(size);this._writeIndex=0;this._startFrame=-1;this._firstNonZeroFrame=-1;this._lastNonZeroFrame=-1;this._energySumSq=0;this._firstNonZeroWriteIndexEver=-1;this._processCount=0;this._maxAbsEver=0;this._firstNonZeroWriteIndex=-1;this._nonZeroQuantumCount=0;this._totalSamplesWritten=0;this._wrapCount=0;this._quantumLenHist={};',
        'this.port.onmessage=(e)=>{',
          'var d=e.data,id=d[0],method=d[1],args=d.slice(2);',
          'switch(method){',
            'case"ping":this.port.postMessage([id,"pong"]);break;',
            'case"getStats":this.port.postMessage([id,{processCount:this._processCount,writeIndex:this._writeIndex,bufferSize:this._bufferSize,wrapCount:this._wrapCount,maxAbsEver:this._maxAbsEver,firstNonZeroWriteIndex:this._firstNonZeroWriteIndex,nonZeroQuantumCount:this._nonZeroQuantumCount,totalSamplesWritten:this._totalSamplesWritten,quantumLenHist:this._quantumLenHist,startFrame:this._startFrame,firstNonZeroFrame:this._firstNonZeroFrame,lastNonZeroFrame:this._lastNonZeroFrame,energySumSq:this._energySumSq}]);break;',
            'case"read":{',
              'var len=args[0]!==undefined?args[0]:this._bufferSize;',
              'var safeLen=Math.min(len,this._bufferSize);',
              'var res=new Float32Array(safeLen);',
              'var wi=this._writeIndex,bs=this._bufferSize,buf=this._buffer;',
              'for(var i=0;i<safeLen;i++){res[i]=buf[(wi-safeLen+i+bs)%bs]}',
              'this.port.postMessage([id,res]);break;',
            '}',
            'case"readWindow":{',
              'var start=args[0]!==undefined?args[0]:0;',
              'var len=args[1]!==undefined?args[1]:this._writeIndex;',
              'var safeLen=Math.min(len,this._bufferSize-start);',
              'if(safeLen<=0){this.port.postMessage([id,new Float32Array(0)]);break}',
              'var res=new Float32Array(safeLen);',
              'var buf=this._buffer;',
              'for(var i=0;i<safeLen;i++){res[i]=buf[start+i]}',
              'this.port.postMessage([id,res]);break;',
            '}',
            'case"clear":{this._buffer.fill(0);this._writeIndex=0;this._firstNonZeroWriteIndex=-1;this._nonZeroQuantumCount=0;this._energySumSq=0;this.port.postMessage([id,true]);break;}',
            'case"markStart":this._startFrame=currentFrame;this.port.postMessage([id,this._startFrame]);break;',
            'default:this.port.postMessage([id,null])',
          '}',
        '}',
      '}',
      'process(inputs,outputs){',
        'this._processCount++;',
        'var input=inputs[0],output=outputs[0];',
        'if(output&&output.length>0&&output[0]){',
          'if(input&&input.length>0&&input[0]){',
            'for(var c=0;c<output.length&&c<input.length;c++){output[c].set(input[c])}',
          '}else{for(var c=0;c<output.length;c++){output[c].fill(0)}}',
        '}',
        'if(!input||input.length===0||input[0].length===0)return true;',
        'var ch=input[0],len=ch.length,buf=this._buffer,bs=this._bufferSize,wi=this._writeIndex;var hasNonZero=false;var qStart=currentFrame;',
        'for(var i=0;i<len;i++){var s=ch[i];var a=(s<0)?-s:s;if(a>this._maxAbsEver)this._maxAbsEver=a;if(s<-1e-6||s>1e-6){hasNonZero=true;if(this._firstNonZeroWriteIndex<0){this._firstNonZeroWriteIndex=wi;this._firstNonZeroWriteIndexEver=wi;this._firstNonZeroFrame=qStart+i}this._lastNonZeroFrame=qStart+i}this._energySumSq+=s*s;buf[wi]=s;wi=(wi+1)%bs}',
        'if(hasNonZero)this._nonZeroQuantumCount++;this._totalSamplesWritten+=len;this._wrapCount+=Math.floor((this._writeIndex+len)/bs);this._quantumLenHist[String(len)]=(this._quantumLenHist[String(len)]||0)+1;this._writeIndex=wi;',
        'return true',
      '}',
    '}',
    'registerProcessor(CAPTURE_NAME,CaptureProcessor);',
  ].join('')

  // ── 3.5. Генерация тестового сигнала (вариант B: 2с = 0.5s тишина + 0.5s 440Hz sine + 1s tail) ──
  const makeSignal = (sr) => {
    const totalLen = Math.ceil(sr * 2.0)
    const silenceLen = Math.ceil(sr * 0.5)
    const sineLen = Math.ceil(sr * 0.5)
    const amp = 0.5
    const buf = new Float32Array(totalLen)
    for (let i = silenceLen; i < silenceLen + sineLen; i++) {
      buf[i] = amp * Math.sin(2 * Math.PI * 440 * (i - silenceLen) / sr)
    }
    return buf
  }
  
  // ── 3.6. v6.21 (MICRO-PACK-081): генерация клика (transient test) + reference ──
  // Gate 3B: клик 1мс @ 44.1кГц = 44 сэмпла (production-representative transient).
  // Gate 3A: single-sample (1 сэмпл) — известный vendor edge-case (FAIL не блокирует 3B).
  const makeClick = (sr, clickLen) => {
    const totalLen = Math.ceil(sr * 0.5)          // 0.5с буфер (как impulse v6.20)
    const buf = new Float32Array(totalLen)
    const n = Math.min(clickLen, totalLen)
    for (let i = 0; i < n; i++) buf[i] = 1.0       // прямоугольный клик амплитуды 1.0
    return buf
  }
  // Reference энергии для клика длиной L: sumSq входа = L×1.0² = L.
  // STFT k-фактор (эмпирический, из v6.16-6.20 single-sample): energy 1.063894 / sumSq 1.0 → k ≈ 1.0639.
  // refEnergy = L × k. Порог [0.5, 1.5] × refEnergy — НЕ слепая цифра 1.063894.
  const clickRefEnergy = (clickLen) => clickLen * 1.0639
  const REF_ENERGY_MIN = 0.5, REF_ENERGY_MAX = 1.5
  // Диапазон peak/√energy — STIMULUS-AWARE.
  // Single-sample (clickLen=1): ratio ≈ 1.0 → [0.3, 2.0] (исторический).
  // Click-44: ratio ≈ 1.0/√44 ≈ 0.151 → [0.08, 0.4].
  // Общая формула: base_ratio / √clickLen, base_ratio ≈ 1.0.
  const PEAK_ENERGY_BASE_RATIO = 1.0
  const peakEnergyMin = (clickLen) => Math.max(0.08, PEAK_ENERGY_BASE_RATIO / Math.sqrt(clickLen) * 0.5)
  const peakEnergyMax = (clickLen) => PEAK_ENERGY_BASE_RATIO / Math.sqrt(clickLen) * 2.5
  // Для clickLen=1: [0.5, 2.5] → сужаем до исторических [0.3, 2.0]
  // Для clickLen=44: [0.08, 0.4]

  // ── 4. Один прогон варианта B/A/C/D ──
  const runVariant = async (variant) => {
    const v = { variant, stage: 'running', errors: [] }
    let ctx = null
    try {
      ctx = new AudioContext({ sampleRate: 44100 })
      v.ctxState = ctx.state
      if (ctx.state === 'suspended') {
        try { await ctx.resume() } catch (e) { v.errors.push('ctx.resume: ' + e.message) }
        v.ctxState = ctx.state
      }
      const sr = ctx.sampleRate
      v.sampleRate = sr

      await ctx.audioWorklet.addModule(URL.createObjectURL(new Blob([code], { type: 'text/javascript' })))
      v.captureModuleLoaded = true

      const isD = variant === 'D'
      const channels = variant === 'B' ? 1 : 2
      const node = await SignalsmithStretch(ctx, {
        numberOfInputs: isD ? 1 : 0,
        numberOfOutputs: 1,
        outputChannelCount: [channels],
      })
      await (node).configure({ blockMs: 40, intervalMs: 20, splitComputation: true })
      v.configured = true

      const latency = await node.latency()
      const latencySamples = Math.round(latency * sr)
      v.latencySamples = latencySamples
      v.latencyMs = Number((latency * 1000).toFixed(2))

      const capBufferSize = Math.max(latencySamples * 4, 44100 * 4)
      const captureNode = new AudioWorkletNode(ctx, CAPTURE_NAME, {
        numberOfInputs: 1,
        numberOfOutputs: 1,
        processorOptions: { bufferSize: capBufferSize },
      })
      try { captureNode.port.start() } catch (e) { v.errors.push('port.start: ' + e.message) }
      captureNode.port.onmessage = (e) => {
        const d = e?.data
        if (Array.isArray(d) && d[1] === 'pong') v._captureOnmessageSeen = true
      }
      captureNode.addEventListener('processorerror', (e) => {
        v.captureProcessorError = String(e?.message ?? e)
        console.log('[ImpulseTest-v6.22/' + variant + '] CAPTURE processorerror:', e?.message ?? e)
      })
      const silentGain = ctx.createGain()
      silentGain.gain.value = 0.000001
      node.connect(captureNode)
      captureNode.connect(silentGain)
      silentGain.connect(ctx.destination)
      v.chainConnected = true
      await new Promise(r => setTimeout(r, 500))

      await rpc(node, 'setInstrumentation', [true])
      v.capturePing = await rpc(captureNode, 'ping', [], 2000)

      const signalBuf = makeSignal(sr)
      if (isD) {
        const audioBuffer = ctx.createBuffer(channels, signalBuf.length, sr)
        for (let c = 0; c < channels; c++) audioBuffer.copyToChannel(signalBuf, c)
        const src = ctx.createBufferSource()
        src.buffer = audioBuffer
        src.connect(node)
        v.inputPath = 'live-input (AudioBufferSource → node.input)'
        v.addBuffersOk = true
        await rpc(captureNode, 'clear', [], 2000)
        src.start()
        await rpc(captureNode, 'markStart', [], 2000)
        v.startOk = true
        v.startRes = 'AudioBufferSource started'
      } else {
        let buffers = []
        if (channels === 1) {
          buffers.push(signalBuf)
        } else {
          const signalBufR = new Float32Array(signalBuf.length)
          signalBufR.set(signalBuf)
          buffers.push(signalBuf, signalBufR)
        }
        const addRes = await rpc(node, 'addBuffers', [buffers])
        if (addRes === null) v.errors.push('addBuffers timeout')
        v.addBuffersOk = addRes !== null
        v.inputPath = channels === 1 ? 'playback mono addBuffers([[1ch]])' : 'playback stereo addBuffers([[2ch]])'
        await rpc(captureNode, 'clear', [], 2000)
        const offset = variant === 'C' ? 0.25 : 0
        const startRes = await rpc(node, 'start', [{ input: offset, rate: 1.0, active: true }])
        await rpc(captureNode, 'markStart', [], 2000)
        if (startRes === null) v.errors.push('start timeout')
        v.startOk = startRes !== null
        v.startOffsetSec = offset
      }

      await new Promise(r => setTimeout(r, 2600))

      v.captureStats = await rpc(captureNode, 'getStats', [], 2000)
      const cs = v.captureStats || {}
      v.wrapCount = cs.wrapCount ?? 0
      v.totalSamplesWritten = cs.totalSamplesWritten ?? 0
      v.maxAbsEver = cs.maxAbsEver ?? 0
      v.firstNonZeroWriteIndex = cs.firstNonZeroWriteIndex ?? -1
      v.nonZeroQuantumCount = cs.nonZeroQuantumCount ?? 0
      v.quantumLenHist = cs.quantumLenHist ?? {}
      const captured = await rpc(captureNode, 'read', [capBufferSize])
      v.capturedLen = captured && captured.length ? captured.length : 0
      v._onmessageSeen = !!v._captureOnmessageSeen

      if (!captured || captured.length === 0) {
        v.stage = 'no-capture'
        v.error = 'capture empty/timeout'
      } else {
        let peakIndex = -1, peakAmplitude = 0, outputSum = 0
        for (let i = 0; i < captured.length; i++) {
          const abs = Math.abs(captured[i])
          outputSum += abs
          if (abs > peakAmplitude) { peakAmplitude = abs; peakIndex = i }
        }
        v.peakIndex = peakIndex
        v.peakAmplitude = Number(peakAmplitude.toFixed(6))
        v.outputSum = Number(outputSum.toFixed(4))
        let capSumSq = 0
        for (let i = 0; i < captured.length; i++) capSumSq += captured[i] * captured[i]
        v.captureRms = Number(Math.sqrt(capSumSq / captured.length).toFixed(6))

        if (peakIndex >= 0 && v.captureStats) {
          const wi = v.captureStats.writeIndex
          const bs = v.captureStats.bufferSize
          const peakWriteIndex = (wi - captured.length + peakIndex + bs) % bs
          v.peakWriteIndex = peakWriteIndex
          v.measuredDelaySamples = peakWriteIndex
          v.measuredDelayMs = Number(((peakWriteIndex / sr) * 1000).toFixed(2))
          v.sampleShift = peakWriteIndex - latencySamples
        }

        v.instrumentation = await rpc(node, 'getInstrumentMetrics', [])
        const ins = v.instrumentation || {}
        const maxSec = (ins.inputSamplesEnd?.max ?? 0) / sr
        const validation = {
          inputSamplesEndMaxSec: Number(maxSec.toFixed(3)),
          valid_leq_1_5s: maxSec <= 1.5,
          copyCount: ins.copyCount ?? 0,
          skipCount: ins.skipCount ?? 0,
          blockSamples: ins.blockSamples ?? { last: 0, max: 0 },
          buffersInRms: ins.buffersInRms ?? { last: 0, max: 0 },
          buffersOutRms: ins.buffersOutRms ?? { last: 0, max: 0 },
          audioBuffersStart: ins.audioBuffersStart ?? 0,
          audioBuffersEnd: ins.audioBuffersEnd ?? 0,
          audioBuffersCount: ins.audioBuffersCount ?? 0,
          audioBufferIndexMax: ins.audioBufferIndex_max ?? 0,
          processCalls: ins.processCalls ?? 0,
          dropoutCount: ins.dropoutCount ?? 0,
          latencySamples: ins.latencySamples ?? latencySamples,
          capturePeak: v.peakAmplitude ?? 0,
          captureRms: v.captureRms ?? 0,
        }
        v.validation = validation

        const copyOk = validation.copyCount > 0
        const inOk = (validation.buffersInRms.max ?? 0) > 0
        const outOk = (validation.buffersOutRms.max ?? 0) > 0
        const capOk = (v.peakAmplitude ?? 0) > 0
        const dropoutOk = (validation.dropoutCount ?? 0) === 0
        const timeOk = validation.valid_leq_1_5s
        v.verdict = {
          inputPath: v.inputPath ?? '',
          wasmOutput: (validation.buffersOutRms.max ?? 0) > 0 ? 'NONZERO' : 'ZERO',
          captureOutput: capOk ? 'NONZERO' : 'ZERO',
          validity: {
            inputSamplesEndMaxSec: validation.inputSamplesEndMaxSec,
            valid_leq_1_5s: timeOk,
            copyCount: validation.copyCount,
            buffersInRmsMax: validation.buffersInRms.max,
            buffersOutRmsMax: validation.buffersOutRms.max,
            capturePeak: v.peakAmplitude ?? 0,
            dropoutCount: validation.dropoutCount ?? 0,
          },
          nextAction: '',
        }
        if (timeOk && copyOk && inOk && outOk && capOk && dropoutOk) {
          v.verdict.nextAction = 'GATE3_WORKING: непрерывный сигнал проходит → затем impulse/null-test на корректном режиме'
        } else if (inOk && !outOk && !capOk) {
          v.verdict.nextAction = 'WASM_SILENT: buffersIn ненулевой, WASM output нулевой → разбор _seek/_process (НЕ REGIME 0/ring-buffer/crossfade)'
        } else if (!inOk) {
          v.verdict.nextAction = 'NO_INPUT: buffersIn пустой → copyCount/blockSamples диагностика чтения audioBuffers'
        } else if (outOk && !capOk) {
          v.verdict.nextAction = 'CAPTURE_GAP: WASM output ненулевой, capture нулевой → capture chain диагностика'
        } else {
          v.verdict.nextAction = 'MIXED: ' + JSON.stringify({ copyOk, inOk, outOk, capOk, dropoutOk, timeOk })
        }
        v.gate3 = (timeOk && copyOk && inOk && outOk && capOk && dropoutOk) ? 'PASS' : 'FAIL'
      }

      v.stage = 'done'
    } catch (e) {
      v.stage = 'error'
      v.error = String(e?.message ?? e)
    } finally {
      try { if (ctx) await ctx.close() } catch (e) { v.errors.push('ctx.close: ' + e.message) }
    }
    return v
  }

  // ── 4b. Вариант E — IMPULSE (Gate 3): peak-based onset, readWindow, denormal threshold ──
  const runImpulseVariant = async (intervalMs, isWarmup, clickLen = 1) => {
    const v = { variant: 'E', stage: 'running', errors: [] }
    v.intervalMs = intervalMs
    v.warmup = !!isWarmup
    v.clickLen = clickLen
    v.stimulusLabel = clickLen === 1 ? 'single-sample (Gate 3A — known vendor edge-case)' : ('click-' + clickLen + ' (Gate 3B — production-representative transient)')
    let ctx = null
    try {
      ctx = new AudioContext({ sampleRate: 44100 })
      v.ctxState = ctx.state
      if (ctx.state === 'suspended') {
        try { await ctx.resume() } catch (e) { v.errors.push('ctx.resume: ' + e.message) }
        v.ctxState = ctx.state
      }
      const sr = ctx.sampleRate
      v.sampleRate = sr

      await ctx.audioWorklet.addModule(URL.createObjectURL(new Blob([code], { type: 'text/javascript' })))
      v.captureModuleLoaded = true

      const node = await SignalsmithStretch(ctx, {
        numberOfInputs: 0,
        numberOfOutputs: 1,
        outputChannelCount: [1],
      })
      await (node).configure({ blockMs: 40, intervalMs: intervalMs, splitComputation: true })
      v.configured = true

      const latency = await node.latency()
      const latencySamples = Math.round(latency * sr)
      v.latencySamples = latencySamples
      v.latencyMs = Number((latency * 1000).toFixed(2))

      // ЕДИНЫЙ буфер под наибольший latency в sweep (intervalMs=40 → 80мс → 3528 samples)
      const capBufferSize = Math.max(3528 * 4, 44100 * 4)
      const captureNode = new AudioWorkletNode(ctx, CAPTURE_NAME, {
        numberOfInputs: 1,
        numberOfOutputs: 1,
        processorOptions: { bufferSize: capBufferSize },
      })
      try { captureNode.port.start() } catch (e) { v.errors.push('port.start: ' + e.message) }
      const silentGain = ctx.createGain()
      silentGain.gain.value = 0.000001
      node.connect(captureNode)
      captureNode.connect(silentGain)
      silentGain.connect(ctx.destination)
      v.chainConnected = true
      await new Promise(r => setTimeout(r, 500))

      await rpc(node, 'setInstrumentation', [true])
      v.capturePing = await rpc(captureNode, 'ping', [], 2000)

      // v6.21 (MICRO-PACK-081): стимул = клик clickLen сэмплов (Gate 3B: 44; Gate 3A: 1)
      const impulseLen = Math.ceil(sr * 0.5)
      const impulseSignal = makeClick(sr, clickLen)
      const addRes = await rpc(node, 'addBuffers', [[impulseSignal]])
      if (addRes === null) v.errors.push('addBuffers timeout')
      v.addBuffersOk = addRes !== null
      v.inputPath = 'playback mono click addBuffers([[1ch]])'

      await rpc(captureNode, 'clear', [], 2000)
      // v6.20 (Opus Variant B): markStart УБРАН. vendorStartFrame фиксируется внутри vendor
      // через глобальный currentFrame в момент фактического принятия start. Обе точки
      // (vendorStartFrame и firstNonZeroFrame) — единый audio clock AudioContext → нет
      // межворклетной гонки capture-vs-vendor (дефект A v6.18: onset 2020 = +256).
      const startRes = await rpc(node, 'start', [{ input: 0, rate: 1.0, active: true }])
      if (startRes === null) v.errors.push('start timeout')
      v.startOk = startRes !== null
      v.syncMode = 'vendor-currentFrame-variant-B'   // фиксация: Вариант B (вердикт Опуса Round 38)

      // READINESS BARRIER: ждём, пока vendor реально начал обработку (processCalls >= 1)
      const barrierStart = Date.now()
      let vendorProcessCalls = 0
      while ((Date.now() - barrierStart) < 2000) {
        const m = await rpc(node, 'getInstrumentMetrics', [], 500)
        vendorProcessCalls = (m && m.processCalls) ?? 0
        if (vendorProcessCalls >= 1) break
        await new Promise(r => setTimeout(r, 50))
      }
      v.vendorReady = vendorProcessCalls >= 1
      v.vendorProcessCallsAtBarrier = vendorProcessCalls
      v.barrierWaitedMs = Date.now() - barrierStart

      const waitMs = (latency * 1000) + 300
      await new Promise(r => setTimeout(r, waitMs))

      v.captureStats = await rpc(captureNode, 'getStats', [], 2000)
      const cs = v.captureStats || {}
      v.processCount = cs.processCount ?? 0
      v.startFrameRaw = cs.startFrame ?? -1
      v.firstNonZeroFrameRaw = cs.firstNonZeroFrame ?? -1
      v.wrapCount = cs.wrapCount ?? 0
      v.totalSamplesWritten = cs.totalSamplesWritten ?? 0
      v.maxAbsEver = cs.maxAbsEver ?? 0
      v.firstNonZeroWriteIndex = cs.firstNonZeroWriteIndex ?? -1
      v.nonZeroQuantumCount = cs.nonZeroQuantumCount ?? 0
      v.quantumLenHist = cs.quantumLenHist ?? {}

      // РАЗДЕЛЬНЫЕ latency из ТОГО ЖЕ vendor RPC (атомарно с остальными метриками)
      v.instrumentation = await rpc(node, 'getInstrumentMetrics', [])
      const insE = v.instrumentation || {}
      // v6.20: vendorStartFrame + диагностика Дефекта B (quantumTrace)
      v.vendorStartFrame = insE.vendorStartFrame ?? -1
      v.vendorStartCount = insE.startCount ?? 0
      v.vendorConfigureCount = insE.configureCount ?? 0
      v.vendorResetCount = insE.resetCount ?? 0
      v.vendorSeekCount = insE.seekCount ?? 0
      v.vendorLastSeekFrame = insE.lastSeekFrame ?? -1
      v.vendorFirstInputBlockFrame = insE.firstInputBlockFrame ?? -1
      v.vendorFirstOutputBlockFrame = insE.firstOutputBlockFrame ?? -1
      v.vendorQuantumTrace = insE.quantumTrace ?? []
      // v6.20 (MICRO-PACK-080): трассировка Дефекта B — seekTrace/abortSnapshot (measurement only)
      v.vendorSeekTrace = insE.seekTrace ?? []
      v.vendorAbortSnapshot = insE.abortSnapshot ?? null
      v.inputLatencySeconds = insE.inputLatencySeconds ?? null
      v.outputLatencySeconds = insE.outputLatencySeconds ?? null
      v.inputLatencySamples = insE.inputLatencySeconds != null ? Math.round(insE.inputLatencySeconds * sr) : -1
      v.outputLatencySamples = insE.outputLatencySeconds != null ? Math.round(insE.outputLatencySeconds * sr) : -1
      v.reportedLatencySamplesCheck = (insE.inputLatencySeconds != null && insE.outputLatencySeconds != null)
        ? Math.round((insE.inputLatencySeconds + insE.outputLatencySeconds) * sr) : -1
      v.bufferLength = insE.bufferLength?.max ?? insE.bufferLength?.last ?? 0
      v.blockMsConfigured = 40
      v.intervalMsConfigured = intervalMs
      v.inputSamplesEndMin = insE.inputSamplesEnd?.min ?? 0
      v.inputSamplesEndMax = insE.inputSamplesEnd?.max ?? 0

      // ATOMIC readWindow(0, writeIndex) — фикс race condition
      const captured = await rpc(captureNode, 'readWindow', [0, cs.writeIndex])
      v.capturedLen = captured && captured.length ? captured.length : 0
      v.renderedSamples = cs.writeIndex ?? 0
      v.renderedWindowMs = cs.writeIndex !== undefined ? Number((cs.writeIndex / sr * 1000).toFixed(2)) : -1

      if (!captured || captured.length === 0) {
        v.stage = 'no-capture'
        v.error = 'capture empty/timeout'
      } else {
        // peak-based onset: пик амплитуды в окне [0..writeIndex]
        let peakIndex = -1, peakAmplitude = 0, lastNonZeroIdx = -1
        let capSumSq = 0
        for (let i = 0; i < captured.length; i++) {
          const abs = Math.abs(captured[i])
          capSumSq += captured[i] * captured[i]
          if (abs > peakAmplitude) { peakAmplitude = abs; peakIndex = i }
          if (abs > 1e-6) lastNonZeroIdx = i  // denormal threshold
        }
        v.captureMaxAbs = peakAmplitude.toExponential(3)
        v.peakIndexInWindow = peakIndex
        v.lastNonZeroIndexInWindow = lastNonZeroIdx
        v.windowSumSq = Number(capSumSq.toExponential(6))
        v.energySumSq = cs.energySumSq !== undefined ? Number(cs.energySumSq.toExponential(6)) : -1
        v.impulseResponseMs = lastNonZeroIdx >= 0 ? Number((lastNonZeroIdx / sr * 1000).toFixed(2)) : -1

        // v6.20 (Opus Variant B): onset = firstNonZeroFrame − vendorStartFrame (единый audio clock vendor)
        const peakFrame = cs.firstNonZeroFrame
        const startFrame = v.vendorStartFrame
        v.onsetDelaySamples = (peakFrame >= 0 && startFrame >= 0) ? (peakFrame - startFrame) : -1
        v.onsetDelayMs = v.onsetDelaySamples >= 0 ? Number((v.onsetDelaySamples / sr * 1000).toFixed(2)) : -1
        v.expectedLatencySamples = latencySamples
        v.expectedLatencyMs = Number((latency * 1000).toFixed(2))

        // критерий PRODUCTION (Round 32): |onset - outputLatency| ≤ 128 (±1 квант)
        const onsetOk = v.onsetDelaySamples >= 0 && v.outputLatencySamples >= 0
          && Math.abs(v.onsetDelaySamples - v.outputLatencySamples) <= 128
        v.gate3 = onsetOk ? 'PASS' : 'FAIL'
        v.onsetDiff = (v.onsetDelaySamples >= 0 && v.outputLatencySamples >= 0)
          ? (v.onsetDelaySamples - v.outputLatencySamples) : null
        // v6.21 (MICRO-PACK-081): formOk — STIMULUS-AWARE.
        // Gate 3B (clickLen>1): min. несколько ненулевых квантов, отсутствие truncation,
        // peak/energy ratio в диапазоне reference, энергия в [0.5,1.5]×refEnergy.
        // Gate 3A (clickLen===1): старый критерий сохранён (известный edge-case, не блокирует 3B).
        const refEnergy = clickRefEnergy(clickLen)
        v.refEnergy = Number(refEnergy.toExponential(6))
        const energyNum = typeof v.energySumSq === 'number' ? v.energySumSq : -1
        v.energyRatio = energyNum > 0 ? Number((energyNum / refEnergy).toFixed(3)) : -1
        v.peakEnergyRatio = (energyNum > 0 && v.captureMaxAbs > 0)
          ? Number((Math.abs(v.captureMaxAbs) / Math.sqrt(energyNum)).toFixed(3)) : -1
        // truncation: хвост успел затухнуть до конца окна (не обрывается на последнем кванте)
        const rendered = v.renderedSamples ?? 0
        v.truncated = v.lastNonZeroIndexInWindow >= 0 && rendered > 0
          && (v.lastNonZeroIndexInWindow >= rendered - 128)
        // фаза старта относительно сетки STFT-фреймов (intervalSamples=882 для 40/20)
        v.phaseVendorStartModInterval = v.vendorStartFrame >= 0
          ? (v.vendorStartFrame % 882) : -1
        if (clickLen === 1) {
          // Gate 3A: старый критерий (документированный vendor edge-case)
          v.formOk = (v.nonZeroQuantumCount ?? 0) >= 10 && v.energySumSq > 1.0
        } else {
          // Gate 3B: stimulus-aware
          const qOk = (v.nonZeroQuantumCount ?? 0) >= 3
          const eOk = v.energyRatio >= REF_ENERGY_MIN && v.energyRatio <= REF_ENERGY_MAX
          const peMin = peakEnergyMin(clickLen)
          const peMax = peakEnergyMax(clickLen)
          const peOk = v.peakEnergyRatio >= peMin && v.peakEnergyRatio <= peMax
          v.peakEnergyRatioMin = Number(peMin.toFixed(3))
          v.peakEnergyRatioMax = Number(peMax.toFixed(3))
          v.formOk = qOk && eOk && peOk && !v.truncated
          v.formOkDetail = { nonZeroQuantumCount: v.nonZeroQuantumCount, energyRatio: v.energyRatio,
            peakEnergyRatio: v.peakEnergyRatio, peakEnergyRatioMin: v.peakEnergyRatioMin,
            peakEnergyRatioMax: v.peakEnergyRatioMax, truncated: v.truncated, refEnergy: v.refEnergy }
        }
        // Авто-классификация FAIL (приоритет: zero_output > capture_issue > truncated > delayed > reference_mismatch)
        if (!v.gate3 || !v.formOk) {
          const wasmOutOk = (v.instrumentation?.buffersOutRms?.max ?? 0) > 0
          const capPeakOk = (v.captureMaxAbs ?? 0) > 0
          if (!wasmOutOk) v.failClass = 'zero_output'
          else if (wasmOutOk && !capPeakOk) v.failClass = 'capture_issue'
          else if (v.truncated) v.failClass = 'truncated_response'
          else if (v.onsetDiff > 128) v.failClass = 'delayed_onset'
          else v.failClass = 'reference_mismatch'
          v.failClassDetail = { gate3: v.gate3, formOk: v.formOk, onsetDiff: v.onsetDiff,
            energyRatio: v.energyRatio, nonZeroQuantumCount: v.nonZeroQuantumCount, truncated: v.truncated }
        } else {
          v.failClass = 'PASS'
        }
        // ГИПОТЕЗА (критерий заранее, Соннет): |onset − inputLatencySamples| ≤ 128 на ВСЕХ точках
        v.inputLatencyMatch = v.onsetDelaySamples >= 0 && v.inputLatencySamples >= 0
          && Math.abs(v.onsetDelaySamples - v.inputLatencySamples) <= 128
        v.inputLatencyDiff = v.onsetDelaySamples >= 0 && v.inputLatencySamples >= 0
          ? (v.onsetDelaySamples - v.inputLatencySamples) : null
        // разница onset vs ПОЛНАЯ latency (для подтверждения, что outputLatency = разрыв)
        v.totalLatencyDiff = v.onsetDelaySamples >= 0 && v.reportedLatencySamplesCheck >= 0
          ? (v.onsetDelaySamples - v.reportedLatencySamplesCheck) : null
      }

      v.stage = 'done'
    } catch (e) {
      v.stage = 'error'
      v.error = String(e?.message ?? e)
    } finally {
      try { if (ctx) await ctx.close() } catch (e) { v.errors.push('ctx.close: ' + e.message) }
    }
    return v
  }

  // ── 4c. Вариант F — NULL-TEST (Gate 4): тишина через vendor → RMS < −60dB ──
  const runNullVariant = async () => {
    const v = { variant: 'F', stage: 'running', errors: [] }
    let ctx = null
    try {
      ctx = new AudioContext({ sampleRate: 44100 })
      v.ctxState = ctx.state
      if (ctx.state === 'suspended') {
        try { await ctx.resume() } catch (e) { v.errors.push('ctx.resume: ' + e.message) }
        v.ctxState = ctx.state
      }
      const sr = ctx.sampleRate
      v.sampleRate = sr

      await ctx.audioWorklet.addModule(URL.createObjectURL(new Blob([code], { type: 'text/javascript' })))
      v.captureModuleLoaded = true

      const node = await SignalsmithStretch(ctx, {
        numberOfInputs: 0,
        numberOfOutputs: 1,
        outputChannelCount: [1],
      })
      await (node).configure({ blockMs: 40, intervalMs: 20, splitComputation: true })
      v.configured = true

      const latency = await node.latency()
      const latencySamples = Math.round(latency * sr)
      v.latencySamples = latencySamples
      v.latencyMs = Number((latency * 1000).toFixed(2))

      const capBufferSize = Math.max(3528 * 4, 44100 * 4)   // единый буфер как в E
      const captureNode = new AudioWorkletNode(ctx, CAPTURE_NAME, {
        numberOfInputs: 1,
        numberOfOutputs: 1,
        processorOptions: { bufferSize: capBufferSize },
      })
      try { captureNode.port.start() } catch (e) { v.errors.push('port.start: ' + e.message) }
      const silentGain = ctx.createGain()
      silentGain.gain.value = 0.000001
      node.connect(captureNode)
      captureNode.connect(silentGain)
      silentGain.connect(ctx.destination)
      v.chainConnected = true
      await new Promise(r => setTimeout(r, 500))

      await rpc(node, 'setInstrumentation', [true])
      v.capturePing = await rpc(captureNode, 'ping', [], 2000)

      // ТИШИНА: 0.5с нулей
      const nullLen = Math.ceil(sr * 0.5)
      const nullSignal = new Float32Array(nullLen)   // все нули
      const addRes = await rpc(node, 'addBuffers', [[nullSignal]])
      if (addRes === null) v.errors.push('addBuffers timeout')
      v.addBuffersOk = addRes !== null
      v.inputPath = 'null-test: тишина 0.5с addBuffers([[zeros]])'

      await rpc(captureNode, 'clear', [], 2000)
      // markStart fire-and-forget ПЕРЕД start (как E)
      const markStartId = Math.random().toString(36).slice(2)
      captureNode.port.postMessage([markStartId, 'markStart'])
      const startRes = await rpc(node, 'start', [{ input: 0, rate: 1.0, active: true }])
      if (startRes === null) v.errors.push('start timeout')
      v.startOk = startRes !== null

      const waitMs = (latency * 1000) + 300
      await new Promise(r => setTimeout(r, waitMs))

      v.captureStats = await rpc(captureNode, 'getStats', [], 2000)
      const cs = v.captureStats || {}
      v.processCount = cs.processCount ?? 0
      v.wrapCount = cs.wrapCount ?? 0
      v.maxAbsEver = cs.maxAbsEver ?? 0
      v.nonZeroQuantumCount = cs.nonZeroQuantumCount ?? 0
      v.energySumSq = cs.energySumSq !== undefined ? Number(cs.energySumSq.toExponential(6)) : -1

      // атомарное чтение окна
      const captured = await rpc(captureNode, 'readWindow', [0, cs.writeIndex])
      v.capturedLen = captured && captured.length ? captured.length : 0

      // РАЗДЕЛЬНЫЕ latency из ТОГО ЖЕ vendor RPC
      v.instrumentation = await rpc(node, 'getInstrumentMetrics', [])
      const insE = v.instrumentation || {}
      v.inputLatencySeconds = insE.inputLatencySeconds ?? null
      v.outputLatencySeconds = insE.outputLatencySeconds ?? null
      v.inputLatencySamples = insE.inputLatencySeconds != null ? Math.round(insE.inputLatencySeconds * sr) : -1
      v.outputLatencySamples = insE.outputLatencySeconds != null ? Math.round(insE.outputLatencySeconds * sr) : -1
      v.reportedLatencySamplesCheck = (insE.inputLatencySeconds != null && insE.outputLatencySeconds != null)
        ? Math.round((insE.inputLatencySeconds + insE.outputLatencySeconds) * sr) : -1
      v.buffersOutRmsMax = insE.buffersOutRms?.max ?? 0
      v.buffersInRmsMax = insE.buffersInRms?.max ?? 0
      v.copyCount = insE.copyCount ?? 0
      v.dropoutCount = insE.dropoutCount ?? 0
      v.processCalls = insE.processCalls ?? 0

      if (!captured || captured.length === 0) {
        v.stage = 'no-capture'
        v.error = 'capture empty/timeout'
      } else {
        // RMS по захваченному окну (амплитуда)
        let peakAbs = 0, sumSq = 0
        for (let i = 0; i < captured.length; i++) {
          const a = Math.abs(captured[i])
          if (a > peakAbs) peakAbs = a
          sumSq += captured[i] * captured[i]
        }
        v.captureRms = Number(Math.sqrt(sumSq / captured.length).toFixed(9))
        v.captureRmsDb = v.captureRms > 0 ? Number((20 * Math.log10(v.captureRms)).toFixed(2)) : -Infinity
        v.capturePeakAbs = Number(peakAbs.toExponential(3))

        // GATE 4 КРИТЕРИЙ: RMS < −60 dB (т.е. < 0.001)
        const THRESHOLD = 0.001
        v.gate4Threshold = THRESHOLD
        v.gate4 = v.captureRms < THRESHOLD ? 'PASS' : 'FAIL'
        v.gate4Note = 'null-test: тишина через vendor → capture RMS < −60dB (0.001)'
      }

      v.stage = 'done'
    } catch (e) {
      v.stage = 'error'
      v.error = String(e?.message ?? e)
    } finally {
      try { if (ctx) await ctx.close() } catch (e) { v.errors.push('ctx.close: ' + e.message) }
    }
    return v
  }

  // ── 4e. v6.21 (MICRO-PACK-081): ВАРИАНТ K — контрольный DIRECT PATH (БЕЗ Signalsmith).
  // AudioBufferSourceNode (тот же клик 44 сэмпла) → captureNode → silentGain → destination.
  // Доказывает: стимул, capture window и reference НЕ теряют transient сами по себе.
  const runControlVariant = async () => {
    const v = { variant: 'K', stage: 'running', errors: [] }
    let ctx = null
    try {
      ctx = new AudioContext({ sampleRate: 44100 })
      v.ctxState = ctx.state
      if (ctx.state === 'suspended') {
        try { await ctx.resume() } catch (e) { v.errors.push('ctx.resume: ' + e.message) }
        v.ctxState = ctx.state
      }
      const sr = ctx.sampleRate
      v.sampleRate = sr

      await ctx.audioWorklet.addModule(URL.createObjectURL(new Blob([code], { type: 'text/javascript' })))
      v.captureModuleLoaded = true

      const capBufferSize = Math.max(3528 * 4, 44100 * 4)
      const captureNode = new AudioWorkletNode(ctx, CAPTURE_NAME, {
        numberOfInputs: 1, numberOfOutputs: 1,
        processorOptions: { bufferSize: capBufferSize },
      })
      try { captureNode.port.start() } catch (e) { v.errors.push('port.start: ' + e.message) }
      const silentGain = ctx.createGain()
      silentGain.gain.value = 0.000001
      captureNode.connect(silentGain)
      silentGain.connect(ctx.destination)
      v.chainConnected = true
      await new Promise(r => setTimeout(r, 500))

      v.capturePing = await rpc(captureNode, 'ping', [], 2000)

      const clickLen = 44                      // ТОТ ЖЕ клик, что Gate 3B
      const clickSignal = makeClick(sr, clickLen)
      const audioBuffer = ctx.createBuffer(1, clickSignal.length, sr)
      audioBuffer.copyToChannel(clickSignal, 0)
      const src = ctx.createBufferSource()
      src.buffer = audioBuffer
      src.connect(captureNode)                 // ← БЕЗ Signalsmith
      v.inputPath = 'control direct path: AudioBufferSource → capture (no Signalsmith)'

      await rpc(captureNode, 'clear', [], 2000)
      const markStartId = Math.random().toString(36).slice(2)
      captureNode.port.postMessage([markStartId, 'markStart'])
      src.start()
      v.startOk = true

      await new Promise(r => setTimeout(r, 500))

      v.captureStats = await rpc(captureNode, 'getStats', [], 2000)
      const cs = v.captureStats || {}
      v.processCount = cs.processCount ?? 0
      v.wrapCount = cs.wrapCount ?? 0
      v.maxAbsEver = cs.maxAbsEver ?? 0
      v.firstNonZeroFrameRaw = cs.firstNonZeroFrame ?? -1
      v.lastNonZeroFrameRaw = cs.lastNonZeroFrame ?? -1
      v.energySumSq = cs.energySumSq !== undefined ? Number(cs.energySumSq.toExponential(6)) : -1
      v.nonZeroQuantumCount = cs.nonZeroQuantumCount ?? 0

      const captured = await rpc(captureNode, 'readWindow', [0, cs.writeIndex])
      v.capturedLen = captured && captured.length ? captured.length : 0
      if (!captured || captured.length === 0) {
        v.stage = 'no-capture'
        v.error = 'capture empty/timeout'
      } else {
        let peakAbs = 0, sumSq = 0, lastNZ = -1
        for (let i = 0; i < captured.length; i++) {
          const a = Math.abs(captured[i])
          if (a > peakAbs) peakAbs = a
          sumSq += captured[i] * captured[i]
          if (a > 1e-6) lastNZ = i
        }
        v.capturePeakAbs = Number(peakAbs.toExponential(3))
        v.captureEnergySumSq = Number(sumSq.toExponential(6))
        v.expectedEnergySumSq = clickLen                 // sumSq входа клика = 44
        v.energyRatio = sumSq > 0 ? Number((sumSq / clickLen).toFixed(3)) : -1
        v.lastNonZeroIndexInWindow = lastNZ
        // onset ≈ 0: первый ненулевой фрейм почти сразу после startFrame (клик мгновенный)
        v.onsetSamples = cs.firstNonZeroFrame >= 0 && cs.startFrame >= 0
          ? (cs.firstNonZeroFrame - cs.startFrame) : -1
        // Критерий контроля: capture не теряет transient (energy≈44, peak≈1.0, ненулевой квант)
        const eOk = v.energyRatio >= 0.8 && v.energyRatio <= 1.2
        const pOk = peakAbs >= 0.9
        const qOk = v.nonZeroQuantumCount >= 1
        const onsetOk = v.onsetSamples >= 0 && v.onsetSamples <= 256   // ≤2 кванта (артефакт старта допустим)
        v.controlPass = eOk && pOk && qOk && onsetOk
        v.controlDetail = { energyRatio: v.energyRatio, peakAbs: Number(peakAbs.toFixed(3)),
          nonZeroQuantumCount: v.nonZeroQuantumCount, onsetSamples: v.onsetSamples }
      }
      v.stage = 'done'
    } catch (e) {
      v.stage = 'error'
      v.error = String(e?.message ?? e)
    } finally {
      try { if (ctx) await ctx.close() } catch (e) { v.errors.push('ctx.close: ' + e.message) }
    }
    return v
  }

  // ── 4d. v6.20 (MICRO-PACK-080): печать DEFECT-B TRACE — только чтение/вывод метрик, НЕ логика прогона ──
  const printDefectBTrace = (v, rep) => {
    const seekTrace = (v.vendorSeekTrace ?? []).slice(0, 200)
    const quantumTrace = (v.vendorQuantumTrace ?? []).slice(0, 1000)
    const energy = v.energySumSq
    const suspect = typeof energy === 'number' && Number(energy) < 1.0
    const trace = {
      rep,
      energySumSq: energy,
      DEFECT_B_SUSPECT: suspect ? true : undefined,
      abortSnapshot: v.vendorAbortSnapshot ?? null,
      seekTraceCount: seekTrace.length,
      seekTrace,
      quantumTraceCount: quantumTrace.length,
      quantumTrace,
    }
    if (suspect) {
      trace.copyCount = v.instrumentation?.copyCount ?? 0
      trace.skipCount = v.instrumentation?.skipCount ?? 0
      trace.blockSamples = v.instrumentation?.blockSamples ?? { last: 0, max: 0 }
      trace.seekTraceLast5 = (v.vendorSeekTrace ?? []).slice(-5)
    }
    return trace
  }

  // ── 5. Запуск v6.21: K (control) → E warmup 3B → 10× E 3B → 5× E 3A → F ──
  const toRun = VARIANT === 'ALL' ? [] : (VARIANT === 'E' ? [] : [VARIANT])
  try {
    for (const vv of toRun) {
      console.log('[ImpulseTest-v6.22] ====== RUN VARIANT ' + vv + ' ======')
      const vr = await runVariant(vv)
      result.variants.push(vr)
      console.log('[ImpulseTest-v6.22/' + vv + '] ======= RESULT =======')
      console.log(JSON.stringify(vr))
    }
    // K: контрольный direct path (без Signalsmith) — 1 прогон
    {
      console.log('[ImpulseTest-v6.22] ====== RUN VARIANT K (control direct path, no Signalsmith) ======')
      const ctrl = await runControlVariant()
      result.controlDirectPath = ctrl
      console.log('[ImpulseTest-v6.22/K] ======= CONTROL RESULT =======')
      console.log(JSON.stringify(ctrl))
    }
    // E Gate 3B: warm-up + 10 повторов, стимул = клик 44 сэмпла
    {
      console.log('[ImpulseTest-v6.22] ====== RUN VARIANT E blockMs=40 intervalMs=20 clickLen=44 (WARMUP 3B) ======')
      const wu = await runImpulseVariant(20, true, 44)
      console.log('[ImpulseTest-v6.22/E3B/warmup] ======= WARMUP RESULT (отброшен) =======')
      console.log(JSON.stringify(wu))
      await new Promise(r => setTimeout(r, 500))
      for (let rep = 1; rep <= 10; rep++) {
        console.log('[ImpulseTest-v6.22] ====== RUN VARIANT E3B rep=' + rep + ' (click 44) ======')
        const vr = await runImpulseVariant(20, false, 44)
        result.variants.push(vr)
        vr.rep = rep
        console.log('[ImpulseTest-v6.22/E3B/rep' + rep + '] ======= RESULT =======')
        console.log(JSON.stringify(vr))
        console.log('[ImpulseTest-v6.22/E3B/rep' + rep + '] ======= DEFECT-B TRACE =======')
        console.log(JSON.stringify(printDefectBTrace(vr, rep)))
        if (rep < 10) await new Promise(r => setTimeout(r, 500))
      }
    }
    // E Gate 3A: 5 повторов single-sample (known vendor edge-case, FAIL ожидаем ~17%, НЕ блокирует 3B)
    {
      console.log('[ImpulseTest-v6.22] ====== RUN VARIANT E3A (single-sample, known vendor edge-case) ======')
      for (let rep = 1; rep <= 5; rep++) {
        console.log('[ImpulseTest-v6.22] ====== RUN VARIANT E3A rep=' + rep + ' (single-sample) ======')
        const vr = await runImpulseVariant(20, false, 1)
        result.variants.push(vr)
        console.log('[ImpulseTest-v6.22/E3A/rep' + rep + '] ======= RESULT =======')
        console.log(JSON.stringify(vr))
        if (rep < 5) await new Promise(r => setTimeout(r, 500))
      }
    }
    // F: null-test (Gate 4a)
    {
      console.log('[ImpulseTest-v6.22] ====== RUN VARIANT F (null-test) ======')
      const vr = await runNullVariant()
      result.variants.push(vr)
      console.log('[ImpulseTest-v6.22/F] ======= RESULT =======')
      console.log(JSON.stringify(vr))
    }
    // v6.21: production config guard + сводка
    {
      const e3b = result.variants.filter(x => x.variant === 'E' && !x.warmup && x.clickLen === 44)
      const pass3b = e3b.filter(x => x.gate3 === 'PASS' && x.formOk)
      const fail3b = e3b.filter(x => !(x.gate3 === 'PASS' && x.formOk))
      result.gate3bSummary = {
        total: e3b.length,
        pass: pass3b.length,
        fail: fail3b.length,
        failClasses: fail3b.reduce((acc, x) => { acc[x.failClass] = (acc[x.failClass] || 0) + 1; return acc }, {}),
        phases: e3b.map(x => ({ rep: x.rep ?? null, phase: x.phaseVendorStartModInterval,
          gate3: x.gate3, formOk: x.formOk, failClass: x.failClass, onsetDiff: x.onsetDiff })),
      }
      const ctrl = result.controlDirectPath
      result.productionConfigGuard = {
        blockMs: 40, intervalMs: 20,
        validForProduction: true,
        note: 'EDGE_PROFILES intervalMs 10/40 — НЕ для production без отдельного acceptance (sweep — диагностика)',
      }
      result.gate3bGate = (ctrl?.controlPass && e3b.length === 10 && pass3b.length === 10)
        ? 'PASS' : 'BLOCKED'
      result.gate3bGateNote = 'PASS требует: control direct path OK + 10/10 корректных клик-44 без truncation и с согласованной reference energy'
      console.log('[ImpulseTest-v6.22] ======= GATE 3B SUMMARY =======')
      console.log(JSON.stringify(result.gate3bSummary))
      console.log('[ImpulseTest-v6.22] ======= GATE 3B GATE: ' + result.gate3bGate + ' =======')
    }
    result.stage = 'done'
  } catch (e) {
    result.stage = 'error'
    result.error = String(e?.message ?? e)
  }

  window.__impulseResultV622 = result
  console.log('[ImpulseTest-v6.22] ======= ALL VARIANTS DONE =======')
  console.log(JSON.stringify(result))
  return JSON.stringify(result)
})().catch(e => {
  const err = { stage: 'error', error: String(e?.message ?? e) }
  if (window.__impulseResultV622?.errors?.length) err.errors = window.__impulseResultV622.errors
  window.__impulseResultV622 = err
  console.log('[ImpulseTest-v6.22] ======= ERROR =======')
  console.log(JSON.stringify(err))
  return JSON.stringify(err)
})