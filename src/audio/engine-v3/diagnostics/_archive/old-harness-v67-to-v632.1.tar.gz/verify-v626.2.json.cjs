#!/usr/bin/env node
/**
 * v6.26.2 JSON Verifier (independent, read-only)
 * Usage: node verify-v626.2.json.cjs <path-to-impulse-v626.2-*.json>
 * Recomputes all counts from raw rows. No root-cause claims.
 * Does NOT close Gate4a unless F present and captures non-empty.
 */
'use strict';
const fs = require('fs');
const path = require('path');

const ACCEPTANCE = [128, 256, 4410];
const DIAG = [0, 64];
const REPS = 5;
const MAX_JSON_BYTES = 2 * 1024 * 1024; // v6.26.1 (MICRO-PACK-086 E5): was 55MB, must be < 2MB
const MAX_ARRAY_LEN = 100;              // v6.26.1 (MICRO-PACK-086 E4): COMPACT redaction limit

function err(msg) { console.error('❌ ' + msg); process.exitCode = 1; }
function ok(msg) { console.log('✅ ' + msg); }
function warn(msg) { console.log('⚠️ ' + msg); }

function main() {
  const file = process.argv[2];
  if (!file) { err('usage: node verify-v626.2.json.cjs <json>'); return; }
  let d;
  try { d = JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch (e) { err('cannot parse JSON: ' + e.message); return; }

  // ---- file size (MICRO-PACK-086 E5) ----
  const bytes = fs.statSync(file).size;
  if (bytes >= MAX_JSON_BYTES) err('file size ' + (bytes / 1024 / 1024).toFixed(1) + 'MB >= 2MB (COMPACT violated, was 55MB)');
  else ok('file size ' + (bytes / 1024).toFixed(1) + 'KB < 2MB (COMPACT OK)');

  // ---- metadata ----
  console.log('=== v6.26.2 VERIFIER ===');
  console.log('file:', path.basename(file));
  const m = d.metadata || {};
  console.log('metadata:', JSON.stringify({ version: m.scriptVersion, trackId: m.trackId, sampleRate: m.sampleRate, branch: m.branch, commit: m.commit, splitComputation: m.splitComputation }));
  console.log('provenance:', JSON.stringify({ harnessRevision: m.harnessRevision, harnessSha256: m.harnessSha256, sourcePath: m.sourcePath }));
  console.log('stimulus:', JSON.stringify({ stimulusSource: m.stimulusSource, selectedTrackAffectsStimulus: m.selectedTrackAffectsStimulus, trackPcmActuallyUsed: m.trackPcmActuallyUsed }));

  // ---- provenance (MICRO-PACK-086 E3/E9, Sol_2 cond.1) ----
  if (!m.harnessSha256 || m.harnessSha256 === 'PENDING_OPERATOR_FILLS') err('provenance: harnessSha256 must be a real SHA-256, got ' + JSON.stringify(m.harnessSha256));
  else ok('provenance: harnessSha256 filled (' + String(m.harnessSha256).slice(0, 12) + '...)');
  if (!m.sourcePath || !m.harnessRevision) err('provenance: harnessRevision/sourcePath missing');
  else ok('provenance: harnessRevision=' + m.harnessRevision + ', sourcePath=' + m.sourcePath);

  // ---- stimulus fields (MICRO-PACK-086 E3, Sol_2 cond.6) ----
  if (m.stimulusSource !== 'synthetic_generated_click') err('stimulus: stimulusSource must be synthetic_generated_click, got ' + JSON.stringify(m.stimulusSource));
  else ok('stimulus: stimulusSource = synthetic_generated_click');
  if (m.selectedTrackAffectsStimulus !== false) err('stimulus: selectedTrackAffectsStimulus must be false, got ' + m.selectedTrackAffectsStimulus);
  else ok('stimulus: selectedTrackAffectsStimulus = false');
  if (m.trackPcmActuallyUsed !== false) err('stimulus: trackPcmActuallyUsed must be false, got ' + m.trackPcmActuallyUsed);
  else warn('stimulus: trackPcmActuallyUsed=false: NO track-generalization claim');

  if (!d.rawObservations || !d.computedMetrics || !d.verdict || !d.summary) {
    err('schema: missing top-level block (need rawObservations/computedMetrics/verdict/summary)');
    return;
  }
  ok('schema: 4 top-level blocks present');

  const vendorRows = (d.rawObservations.vendorRows || []).filter(r => r.kind === 'vendor');
  const kRows = d.instrumentHealth?.trueK || [];

  // ---- K independence ----
  const kUsesVendor = kRows.some(r => r.controlTopology && !r.controlTopology.includes('no Signalsmith'));
  if (kRows.length < 2) {
    err('K: expected >=2 rows (offsets 0 and 4410), got ' + kRows.length);
  } else {
    const offsets = kRows.map(r => r.offset).sort((a, b) => a - b);
    if (![0, 4410].every(o => offsets.includes(o))) err('K: missing required offset in ' + JSON.stringify(offsets));
    else ok('K: offsets 0 and 4410 present');
    if (kUsesVendor) err('K: topology references Signalsmith -> not independent');
    else ok('K: no Signalsmith reference in topology');
  }

  // ---- 15 acceptance rows, no missing/duplicate ----
  const acc = vendorRows.filter(r => ACCEPTANCE.includes(r.offset));
  const seen = new Set();
  let dup = 0, miss = [];
  for (const o of ACCEPTANCE) for (let rep = 1; rep <= REPS; rep++) {
    const key = o + ':' + rep;
    if (seen.has(key)) dup++;
    seen.add(key);
    if (!acc.some(r => r.offset === o && r.rep === rep)) miss.push(key);
  }
  if (acc.length !== 15) err('acceptance: expected 15 rows, got ' + acc.length);
  else ok('acceptance: 15 rows present');
  if (dup) err('acceptance: duplicate offset:rep found: ' + dup);
  else ok('acceptance: no duplicates');
  if (miss.length) err('acceptance: missing rows: ' + miss.join(', '));
  else ok('acceptance: no missing offset:rep');

  // ---- diagnostics excluded from denominator ----
  const diag = vendorRows.filter(r => DIAG.includes(r.offset));
  if (diag.length !== 10) err('diagnostics: expected 10 rows (0/64 x5), got ' + diag.length);
  else ok('diagnostics: 0/64 rows present (' + diag.length + '), excluded from denominator');

  // ---- recompute counts from raw rows ----
  const invalid = vendorRows.filter(r => r.verdict?.rowValidity === 'INVALID').length;
  const collapse = acc.filter(r => r.verdict?.transientClass === 'energy_collapse').length;
  const healthy = acc.filter(r => r.verdict?.transientClass === 'healthy').length;
  const formMismatch = acc.filter(r => r.verdict?.transientClass === 'form_mismatch').length;
  const truncated = acc.filter(r => r.verdict?.transientClass === 'truncated_response').length;

  console.log('\n--- recomputed from raw rows ---');
  console.log('vendor rows total:', vendorRows.length);
  console.log('INVALID (harness):', invalid);
  console.log('acceptance energy_collapse:', collapse);
  console.log('acceptance healthy:', healthy);
  console.log('acceptance form_mismatch:', formMismatch);
  console.log('acceptance truncated:', truncated);

  // ---- cross-check against summary ----
  const s = d.summary || {};
  const checks = [
    ['presentAcceptanceRows', acc.length],
    ['validAcceptanceRows', acc.filter(r => r.verdict?.rowValidity === 'VALID').length],
    ['invalidRows', vendorRows.filter(r => r.verdict?.rowValidity === 'INVALID').length],
    ['energyCollapseRows', collapse],
    ['formPassRows', healthy]
  ];
  for (const [k, v] of checks) {
    if (s[k] !== v) err(`summary MISMATCH: ${k} script=${s[k]} recomputed=${v}`);
    else ok(`summary ${k} = ${v}`);
  }

  // ---- invalid rows must NOT be energy_collapse ----
  const badClass = vendorRows.filter(r => r.verdict?.rowValidity === 'INVALID' && r.verdict?.transientClass === 'energy_collapse');
  if (badClass.length) err('INVALID rows classified as energy_collapse: ' + badClass.length);
  else ok('no INVALID row mislabeled as energy_collapse');

  // ---- readWindow redaction (MICRO-PACK-086 E4, COMPACT fix) ----
  let bigArrays = 0;
  for (const r of vendorRows) {
    const rw = r.raw_observations?.rpc?.readWindow?.result;
    if (rw === undefined || rw === null) continue;
    if (Array.isArray(rw) && rw.length > MAX_ARRAY_LEN) { bigArrays++; continue; }
    if (typeof rw === 'object' && !rw.redacted) {
      const keys = Object.keys(rw);
      const numericLen = keys.filter(k => /^\d+$/.test(k)).length;
      if (numericLen > MAX_ARRAY_LEN) bigArrays++;
    }
  }
  if (bigArrays) err('readWindow: ' + bigArrays + ' rpc-records carry raw array > ' + MAX_ARRAY_LEN + ' elems (COMPACT violated)');
  else ok('readWindow: no raw array > ' + MAX_ARRAY_LEN + ' elems in any rpc-record (COMPACT OK)');

  // ---- verdict ----
  const v = d.verdict || {};
  console.log('\n--- verdict ---');
  console.log('harness:', v.harness);
  console.log('gate3BLocal:', v.gate3BLocal);
  console.log('timing:', v.timing);
  console.log('gate4a:', v.gate4a);
  console.log('reasons:', JSON.stringify(v.reasons || []));

  if (v.gate3BLocal === 'PASS') err('verdict: gate3BLocal=PASS always invalid in v6.26.1 (timing UNRESOLVED blocks PASS)');
  if (v.gate4a === 'PASS') err('gate4a: cannot be PASS without independent reference F');
  if (v.gate4a !== 'NOT_RUN' && !d.instrumentHealth?.zeroInputSanity) err('gate4a: verdict present but no zeroInputSanity block');

  // ---- zero-input sanity ----
  const z = d.instrumentHealth?.zeroInputSanity;
  if (z) {
    console.log('\nzeroInputSanity:', JSON.stringify({ captureStatus: z.captureStatus, rmsDb: z.rmsDb, gate4a: z.gate4a, writeIndex: z.writeIndex }));
    if (z.captureStatus === 'no_samples' && z.rms != null) err('zeroInputSanity: rms must be null when no samples');
  } else {
    console.log('\nzeroInputSanity: absent (script did not run F)');
  }

  // ---- timing informational only ----
  const hasTimingCoords = acc.every(r => r.raw_observations?.timingCoords && 'vendorStartFrame' in r.raw_observations.timingCoords);
  if (!hasTimingCoords) err('rows missing timingCoords.vendorStartFrame');
  else ok('all acceptance rows carry timing coordinates (informational)');

  console.log('\n=== VERIFIER DONE ===');
  console.log(process.exitCode ? 'RESULT: MISMATCHES FOUND — see ❌ above' : 'RESULT: ALL CHECKS PASSED');
}

main();
