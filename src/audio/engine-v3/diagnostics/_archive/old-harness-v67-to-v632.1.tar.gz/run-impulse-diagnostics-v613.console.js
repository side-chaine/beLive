// run-impulse-diagnostics-v611.console.js v6.11 — Gate 3: peak-based onset + atomic readWindow
// Авторизация: Опус_4 + Sol_1 (Round 24/25). Без DSP.
// Исправления v6.11: readWindow (атомарное окно [0..writeIndex]), peak-based onset (|peak-latency|≤128), denormal threshold 1e-6

;(async () => {
  const result = { stage: 'running', errors: [], variants: [] }
  window.__impulseResultV613 = result

  // ── 0. Вариант: B | A | C | D | ALL ──
  const VARIANT = (window.__V67_VARIANT || 'ALL').toUpperCase()

  // ── 1. Импорт vendor через Vite dev (base '/beLive/', vite.config.ts:65) ──
  let SignalsmithStretch
  const vendorPaths = [
    '/beLive/src/audio/engine-v3/vendor/SignalsmithStretch.mjs',
    '/src/audio/engine-v3/vendor/SignalsmithStretch.mjs',
  ]
  for (const p of vendorPaths) {
    try {
      const mod = await import(p)
      SignalsmithStretch = mod.default || mod
      result.vendorLoaded = true
      result.vendorPath = p
      console.log('[ImpulseTest-v6.13] vendor loaded from:', p, '→', typeof SignalsmithStretch)
      break
    } catch (e) {
      result.errors.push('vendor import ' + p + ': ' + e.message)
    }
  }
  if (!SignalsmithStretch) {
    result.stage = 'error'
    window.__impulseResultV613 = result
    return JSON.stringify(result)
  }

  // ── 2. RPC helper ──
  const rpc = (n, method, args, timeoutMs = 5000) => new Promise(resolve => {
    if (!n || !n.port) return resolve(null)
    const id = Math.random().toString(36).slice(2)
    const timer = setTimeout(() => { try { n.port.removeEventListener('message', h) } catch (e) {}; resolve(null) }, timeoutMs)
    const h = (e) => { const [mid, data] = e.data; if (mid === id) { clearTimeout(timer); try { n.port.removeEventListener('message', h) } catch (e) {}; resolve(data) } }
    n.port.addEventListener('message', h)
    n.port.postMessage([id, method, ...args])
  })

  // ── 3. Capture worklet (v611: readWindow + denormal threshold 1e-6) ──
  const CAPTURE_NAME = 'belive-capture-processor-v613'
  const code = [
    'var CAPTURE_NAME="belive-capture-processor-v613";',
    'class CaptureProcessor extends AudioWorkletProcessor{',
      'constructor(options){super(options);',
        'var size=(options&&options.processorOptions&&options.processorOptions.bufferSize)||44100;',
        'this._bufferSize=size;this._buffer=new Float32Array(size);this._writeIndex=0;this._startFrame=-1;this._firstNonZeroFrame=-1;this._lastNonZeroFrame=-1;this._energySumSq=0;this._firstNonZeroWriteIndexEver=-1;this._processCount=0;this._maxAbsEver=0;this._firstNonZeroWriteIndex=-1;this._nonZeroQuantumCount=0;this._totalSamplesWritten=0;this._wrapCount=0;this._quantumLenHist={};',
        'this.port.onmessage=(e)=>{',
          'var d=e.data,id=d[0],method=d[1],args=d.slice(2);',
          'switch(method){',
            'case"ping":this.port.postMessage([id,"pong"]);break;',
            'case"getStats":this.port.postMessage([id,{processCount:this._processCount,writeIndex:this._writeIndex,bufferSize:this._bufferSize,wrapCount:this._wrapCount,maxAbsEver:this._maxAbsEver,firstNonZeroWriteIndex:this._firstNonZeroWriteIndex,nonZeroQuantumCount:this._nonZeroQuantumCount,totalSamplesWritten:this._totalSamplesWritten,quantumLenHist:this._quantumLenHist,startFrame:this._startFrame,firstNonZeroFrame:this._firstNonZeroFrame,lastNonZeroFrame:this._lastNonZeroFrame,energySumSq:this._energySumSq}]);break;',
            'case"read":{',
              'var len=args[0]!==undefined?args[0]:this._bufferSize;',
              'var safeLen=Math.min(len,this._bufferSize);',
              'var res=new Float32Array(safeLen);',
              'var wi=this._writeIndex,bs=this._bufferSize,buf=this._buffer;',
              'for(var i=0;i<safeLen;i++){res[i]=buf[(wi-safeLen+i+bs)%bs]}',
              'this.port.postMessage([id,res]);break;',
            '}',
            'case"readWindow":{',
              'var start=args[0]!==undefined?args[0]:0;',
              'var len=args[1]!==undefined?args[1]:this._writeIndex;',
              'var safeLen=Math.min(len,this._bufferSize-start);',
              'if(safeLen<=0){this.port.postMessage([id,new Float32Array(0)]);break}',
              'var res=new Float32Array(safeLen);',
              'var buf=this._buffer;',
              'for(var i=0;i<safeLen;i++){res[i]=buf[start+i]}',
              'this.port.postMessage([id,res]);break;',
            '}',
            'case"clear":{this._buffer.fill(0);this._writeIndex=0;this._firstNonZeroWriteIndex=-1;this._nonZeroQuantumCount=0;this._energySumSq=0;this.port.postMessage([id,true]);break;}',
            'case"markStart":this._startFrame=currentFrame;this.port.postMessage([id,this._startFrame]);break;',
            'default:this.port.postMessage([id,null])',
          '}',
        '}',
      '}',
      'process(inputs,outputs){',
        'this._processCount++;',
        'var input=inputs[0],output=outputs[0];',
        'if(output&&output.length>0&&output[0]){',
          'if(input&&input.length>0&&input[0]){',
            'for(var c=0;c<output.length&&c<input.length;c++){output[c].set(input[c])}',
          '}else{for(var c=0;c<output.length;c++){output[c].fill(0)}}',
        '}',
        'if(!input||input.length===0||input[0].length===0)return true;',
        'var ch=input[0],len=ch.length,buf=this._buffer,bs=this._bufferSize,wi=this._writeIndex;var hasNonZero=false;var qStart=currentFrame;',
        'for(var i=0;i<len;i++){var s=ch[i];var a=(s<0)?-s:s;if(a>this._maxAbsEver)this._maxAbsEver=a;if(s<-1e-6||s>1e-6){hasNonZero=true;if(this._firstNonZeroWriteIndex<0){this._firstNonZeroWriteIndex=wi;this._firstNonZeroWriteIndexEver=wi;this._firstNonZeroFrame=qStart+i}this._lastNonZeroFrame=qStart+i}this._energySumSq+=s*s;buf[wi]=s;wi=(wi+1)%bs}',
        'if(hasNonZero)this._nonZeroQuantumCount++;this._totalSamplesWritten+=len;this._wrapCount+=Math.floor((this._writeIndex+len)/bs);this._quantumLenHist[String(len)]=(this._quantumLenHist[String(len)]||0)+1;this._writeIndex=wi;',
        'return true',
      '}',
    '}',
    'registerProcessor(CAPTURE_NAME,CaptureProcessor);',
  ].join('')

  // ── 3.5. Генерация тестового сигнала (вариант B: 2с = 0.5s тишина + 0.5s 440Hz sine + 1s tail) ──
  const makeSignal = (sr) => {
    const totalLen = Math.ceil(sr * 2.0)
    const silenceLen = Math.ceil(sr * 0.5)
    const sineLen = Math.ceil(sr * 0.5)
    const amp = 0.5
    const buf = new Float32Array(totalLen)
    for (let i = silenceLen; i < silenceLen + sineLen; i++) {
      buf[i] = amp * Math.sin(2 * Math.PI * 440 * (i - silenceLen) / sr)
    }
    return buf
  }

  // ── 4. Один прогон варианта B/A/C/D ──
  const runVariant = async (variant) => {
    const v = { variant, stage: 'running', errors: [] }
    let ctx = null
    try {
      ctx = new AudioContext({ sampleRate: 44100 })
      v.ctxState = ctx.state
      if (ctx.state === 'suspended') {
        try { await ctx.resume() } catch (e) { v.errors.push('ctx.resume: ' + e.message) }
        v.ctxState = ctx.state
      }
      const sr = ctx.sampleRate
      v.sampleRate = sr

      await ctx.audioWorklet.addModule(URL.createObjectURL(new Blob([code], { type: 'text/javascript' })))
      v.captureModuleLoaded = true

      const isD = variant === 'D'
      const channels = variant === 'B' ? 1 : 2
      const node = await SignalsmithStretch(ctx, {
        numberOfInputs: isD ? 1 : 0,
        numberOfOutputs: 1,
        outputChannelCount: [channels],
      })
      await (node).configure({ blockMs: 40, intervalMs: 20, splitComputation: true })
      v.configured = true

      const latency = await node.latency()
      const latencySamples = Math.round(latency * sr)
      v.latencySamples = latencySamples
      v.latencyMs = Number((latency * 1000).toFixed(2))

      const capBufferSize = Math.max(latencySamples * 4, 44100 * 4)
      const captureNode = new AudioWorkletNode(ctx, CAPTURE_NAME, {
        numberOfInputs: 1,
        numberOfOutputs: 1,
        processorOptions: { bufferSize: capBufferSize },
      })
      try { captureNode.port.start() } catch (e) { v.errors.push('port.start: ' + e.message) }
      captureNode.port.onmessage = (e) => {
        const d = e?.data
        if (Array.isArray(d) && d[1] === 'pong') v._captureOnmessageSeen = true
      }
      captureNode.addEventListener('processorerror', (e) => {
        v.captureProcessorError = String(e?.message ?? e)
        console.log('[ImpulseTest-v6.13/' + variant + '] CAPTURE processorerror:', e?.message ?? e)
      })
      const silentGain = ctx.createGain()
      silentGain.gain.value = 0.000001
      node.connect(captureNode)
      captureNode.connect(silentGain)
      silentGain.connect(ctx.destination)
      v.chainConnected = true
      await new Promise(r => setTimeout(r, 500))

      await rpc(node, 'setInstrumentation', [true])
      v.capturePing = await rpc(captureNode, 'ping', [], 2000)

      const signalBuf = makeSignal(sr)
      if (isD) {
        const audioBuffer = ctx.createBuffer(channels, signalBuf.length, sr)
        for (let c = 0; c < channels; c++) audioBuffer.copyToChannel(signalBuf, c)
        const src = ctx.createBufferSource()
        src.buffer = audioBuffer
        src.connect(node)
        v.inputPath = 'live-input (AudioBufferSource → node.input)'
        v.addBuffersOk = true
        await rpc(captureNode, 'clear', [], 2000)
        src.start()
        await rpc(captureNode, 'markStart', [], 2000)
        v.startOk = true
        v.startRes = 'AudioBufferSource started'
      } else {
        let buffers = []
        if (channels === 1) {
          buffers.push(signalBuf)
        } else {
          const signalBufR = new Float32Array(signalBuf.length)
          signalBufR.set(signalBuf)
          buffers.push(signalBuf, signalBufR)
        }
        const addRes = await rpc(node, 'addBuffers', [buffers])
        if (addRes === null) v.errors.push('addBuffers timeout')
        v.addBuffersOk = addRes !== null
        v.inputPath = channels === 1 ? 'playback mono addBuffers([[1ch]])' : 'playback stereo addBuffers([[2ch]])'
        await rpc(captureNode, 'clear', [], 2000)
        const offset = variant === 'C' ? 0.25 : 0
        const startRes = await rpc(node, 'start', [{ input: offset, rate: 1.0, active: true }])
        await rpc(captureNode, 'markStart', [], 2000)
        if (startRes === null) v.errors.push('start timeout')
        v.startOk = startRes !== null
        v.startOffsetSec = offset
      }

      await new Promise(r => setTimeout(r, 2600))

      v.captureStats = await rpc(captureNode, 'getStats', [], 2000)
      const cs = v.captureStats || {}
      v.wrapCount = cs.wrapCount ?? 0
      v.totalSamplesWritten = cs.totalSamplesWritten ?? 0
      v.maxAbsEver = cs.maxAbsEver ?? 0
      v.firstNonZeroWriteIndex = cs.firstNonZeroWriteIndex ?? -1
      v.nonZeroQuantumCount = cs.nonZeroQuantumCount ?? 0
      v.quantumLenHist = cs.quantumLenHist ?? {}
      const captured = await rpc(captureNode, 'read', [capBufferSize])
      v.capturedLen = captured && captured.length ? captured.length : 0
      v._onmessageSeen = !!v._captureOnmessageSeen

      if (!captured || captured.length === 0) {
        v.stage = 'no-capture'
        v.error = 'capture empty/timeout'
      } else {
        let peakIndex = -1, peakAmplitude = 0, outputSum = 0
        for (let i = 0; i < captured.length; i++) {
          const abs = Math.abs(captured[i])
          outputSum += abs
          if (abs > peakAmplitude) { peakAmplitude = abs; peakIndex = i }
        }
        v.peakIndex = peakIndex
        v.peakAmplitude = Number(peakAmplitude.toFixed(6))
        v.outputSum = Number(outputSum.toFixed(4))
        let capSumSq = 0
        for (let i = 0; i < captured.length; i++) capSumSq += captured[i] * captured[i]
        v.captureRms = Number(Math.sqrt(capSumSq / captured.length).toFixed(6))

        if (peakIndex >= 0 && v.captureStats) {
          const wi = v.captureStats.writeIndex
          const bs = v.captureStats.bufferSize
          const peakWriteIndex = (wi - captured.length + peakIndex + bs) % bs
          v.peakWriteIndex = peakWriteIndex
          v.measuredDelaySamples = peakWriteIndex
          v.measuredDelayMs = Number(((peakWriteIndex / sr) * 1000).toFixed(2))
          v.sampleShift = peakWriteIndex - latencySamples
        }

        v.instrumentation = await rpc(node, 'getInstrumentMetrics', [])
        const ins = v.instrumentation || {}
        const maxSec = (ins.inputSamplesEnd?.max ?? 0) / sr
        const validation = {
          inputSamplesEndMaxSec: Number(maxSec.toFixed(3)),
          valid_leq_1_5s: maxSec <= 1.5,
          copyCount: ins.copyCount ?? 0,
          skipCount: ins.skipCount ?? 0,
          blockSamples: ins.blockSamples ?? { last: 0, max: 0 },
          buffersInRms: ins.buffersInRms ?? { last: 0, max: 0 },
          buffersOutRms: ins.buffersOutRms ?? { last: 0, max: 0 },
          audioBuffersStart: ins.audioBuffersStart ?? 0,
          audioBuffersEnd: ins.audioBuffersEnd ?? 0,
          audioBuffersCount: ins.audioBuffersCount ?? 0,
          audioBufferIndexMax: ins.audioBufferIndex_max ?? 0,
          processCalls: ins.processCalls ?? 0,
          dropoutCount: ins.dropoutCount ?? 0,
          latencySamples: ins.latencySamples ?? latencySamples,
          capturePeak: v.peakAmplitude ?? 0,
          captureRms: v.captureRms ?? 0,
        }
        v.validation = validation

        const copyOk = validation.copyCount > 0
        const inOk = (validation.buffersInRms.max ?? 0) > 0
        const outOk = (validation.buffersOutRms.max ?? 0) > 0
        const capOk = (v.peakAmplitude ?? 0) > 0
        const dropoutOk = (validation.dropoutCount ?? 0) === 0
        const timeOk = validation.valid_leq_1_5s
        v.verdict = {
          inputPath: v.inputPath ?? '',
          wasmOutput: (validation.buffersOutRms.max ?? 0) > 0 ? 'NONZERO' : 'ZERO',
          captureOutput: capOk ? 'NONZERO' : 'ZERO',
          validity: {
            inputSamplesEndMaxSec: validation.inputSamplesEndMaxSec,
            valid_leq_1_5s: timeOk,
            copyCount: validation.copyCount,
            buffersInRmsMax: validation.buffersInRms.max,
            buffersOutRmsMax: validation.buffersOutRms.max,
            capturePeak: v.peakAmplitude ?? 0,
            dropoutCount: validation.dropoutCount ?? 0,
          },
          nextAction: '',
        }
        if (timeOk && copyOk && inOk && outOk && capOk && dropoutOk) {
          v.verdict.nextAction = 'GATE3_WORKING: непрерывный сигнал проходит → затем impulse/null-test на корректном режиме'
        } else if (inOk && !outOk && !capOk) {
          v.verdict.nextAction = 'WASM_SILENT: buffersIn ненулевой, WASM output нулевой → разбор _seek/_process (НЕ REGIME 0/ring-buffer/crossfade)'
        } else if (!inOk) {
          v.verdict.nextAction = 'NO_INPUT: buffersIn пустой → copyCount/blockSamples диагностика чтения audioBuffers'
        } else if (outOk && !capOk) {
          v.verdict.nextAction = 'CAPTURE_GAP: WASM output ненулевой, capture нулевой → capture chain диагностика'
        } else {
          v.verdict.nextAction = 'MIXED: ' + JSON.stringify({ copyOk, inOk, outOk, capOk, dropoutOk, timeOk })
        }
        v.gate3 = (timeOk && copyOk && inOk && outOk && capOk && dropoutOk) ? 'PASS' : 'FAIL'
      }

      v.stage = 'done'
    } catch (e) {
      v.stage = 'error'
      v.error = String(e?.message ?? e)
    } finally {
      try { if (ctx) await ctx.close() } catch (e) { v.errors.push('ctx.close: ' + e.message) }
    }
    return v
  }

  // ── 4b. Вариант E — IMPULSE (Gate 3): peak-based onset, readWindow, denormal threshold ──
  const runImpulseVariant = async (intervalMs) => {
    const v = { variant: 'E', stage: 'running', errors: [] }
    v.intervalMs = intervalMs
    let ctx = null
    try {
      ctx = new AudioContext({ sampleRate: 44100 })
      v.ctxState = ctx.state
      if (ctx.state === 'suspended') {
        try { await ctx.resume() } catch (e) { v.errors.push('ctx.resume: ' + e.message) }
        v.ctxState = ctx.state
      }
      const sr = ctx.sampleRate
      v.sampleRate = sr

      await ctx.audioWorklet.addModule(URL.createObjectURL(new Blob([code], { type: 'text/javascript' })))
      v.captureModuleLoaded = true

      const node = await SignalsmithStretch(ctx, {
        numberOfInputs: 0,
        numberOfOutputs: 1,
        outputChannelCount: [1],
      })
      await (node).configure({ blockMs: 40, intervalMs: intervalMs, splitComputation: true })
      v.configured = true

      const latency = await node.latency()
      const latencySamples = Math.round(latency * sr)
      v.latencySamples = latencySamples
      v.latencyMs = Number((latency * 1000).toFixed(2))

      const capBufferSize = Math.max(latencySamples * 4, 44100 * 4)
      const captureNode = new AudioWorkletNode(ctx, CAPTURE_NAME, {
        numberOfInputs: 1,
        numberOfOutputs: 1,
        processorOptions: { bufferSize: capBufferSize },
      })
      try { captureNode.port.start() } catch (e) { v.errors.push('port.start: ' + e.message) }
      const silentGain = ctx.createGain()
      silentGain.gain.value = 0.000001
      node.connect(captureNode)
      captureNode.connect(silentGain)
      silentGain.connect(ctx.destination)
      v.chainConnected = true
      await new Promise(r => setTimeout(r, 500))

      await rpc(node, 'setInstrumentation', [true])
      v.capturePing = await rpc(captureNode, 'ping', [], 2000)

      const impulseLen = Math.ceil(sr * 0.5)
      const impulseSignal = new Float32Array(impulseLen)
      impulseSignal[0] = 1.0
      const addRes = await rpc(node, 'addBuffers', [[impulseSignal]])
      if (addRes === null) v.errors.push('addBuffers timeout')
      v.addBuffersOk = addRes !== null
      v.inputPath = 'playback mono impulse addBuffers([[1ch]])'

      await rpc(captureNode, 'clear', [], 2000)
      // markStart fire-and-forget ПЕРЕД start — чтобы захватить currentFrame ДО первого ненулевого
      const markStartId = Math.random().toString(36).slice(2)
      captureNode.port.postMessage([markStartId, 'markStart'])
      // НЕ await — fire-and-forget, markStart уйдёт в worklet до следующего render quantum
      const startRes = await rpc(node, 'start', [{ input: 0, rate: 1.0, active: true }])
      if (startRes === null) v.errors.push('start timeout')
      v.startOk = startRes !== null

      const waitMs = (latency * 1000) + 150
      await new Promise(r => setTimeout(r, waitMs))

      v.captureStats = await rpc(captureNode, 'getStats', [], 2000)
      const cs = v.captureStats || {}
      v.processCount = cs.processCount ?? 0
      v.wrapCount = cs.wrapCount ?? 0
      v.totalSamplesWritten = cs.totalSamplesWritten ?? 0
      v.maxAbsEver = cs.maxAbsEver ?? 0
      v.firstNonZeroWriteIndex = cs.firstNonZeroWriteIndex ?? -1
      v.nonZeroQuantumCount = cs.nonZeroQuantumCount ?? 0
      v.quantumLenHist = cs.quantumLenHist ?? {}

      // ATOMIC readWindow(0, writeIndex) — фикс race condition
      const captured = await rpc(captureNode, 'readWindow', [0, cs.writeIndex])
      v.capturedLen = captured && captured.length ? captured.length : 0

      if (!captured || captured.length === 0) {
        v.stage = 'no-capture'
        v.error = 'capture empty/timeout'
      } else {
        // peak-based onset: пик амплитуды в окне [0..writeIndex]
        let peakIndex = -1, peakAmplitude = 0, lastNonZeroIdx = -1
        let capSumSq = 0
        for (let i = 0; i < captured.length; i++) {
          const abs = Math.abs(captured[i])
          capSumSq += captured[i] * captured[i]
          if (abs > peakAmplitude) { peakAmplitude = abs; peakIndex = i }
          if (abs > 1e-6) lastNonZeroIdx = i  // denormal threshold
        }
        v.captureMaxAbs = peakAmplitude.toExponential(3)
        v.peakIndexInWindow = peakIndex
        v.lastNonZeroIndexInWindow = lastNonZeroIdx
        v.windowSumSq = Number(capSumSq.toExponential(6))
        v.energySumSq = cs.energySumSq !== undefined ? Number(cs.energySumSq.toExponential(6)) : -1
        v.impulseResponseMs = lastNonZeroIdx >= 0 ? Number((lastNonZeroIdx / sr * 1000).toFixed(2)) : -1

        // onset = peakFrame - startFrame (через currentFrame, НЕ через peakIndex!)
        const peakFrame = cs.firstNonZeroFrame  // или cs.lastNonZeroFrame — пик на первом ненулевом для импульса
        const startFrame = cs.startFrame
        v.onsetDelaySamples = (peakFrame >= 0 && startFrame >= 0) ? (peakFrame - startFrame) : -1
        v.onsetDelayMs = v.onsetDelaySamples >= 0 ? Number((v.onsetDelaySamples / sr * 1000).toFixed(2)) : -1
        v.expectedLatencySamples = latencySamples
        v.expectedLatencyMs = Number((latency * 1000).toFixed(2))

        // критерий: |onsetDelay - latency| ≤ 128 (±1 квант)
        const onsetOk = v.onsetDelaySamples >= 0 && Math.abs(v.onsetDelaySamples - latencySamples) <= 128
        v.gate3 = onsetOk ? 'PASS' : 'FAIL'
        v.onsetDiff = v.onsetDelaySamples >= 0 ? (v.onsetDelaySamples - latencySamples) : null
      }

      v.stage = 'done'
    } catch (e) {
      v.stage = 'error'
      v.error = String(e?.message ?? e)
    } finally {
      try { if (ctx) await ctx.close() } catch (e) { v.errors.push('ctx.close: ' + e.message) }
    }
    return v
  }

  // ── 5. Запуск вариантов: B → A → C → D → E ──
  const order = ['B', 'A', 'C', 'D']
  const sweep = [10, 20, 40]
  const toRun = VARIANT === 'ALL' ? order : (VARIANT === 'E' ? [] : order.filter(x => x === VARIANT))
  try {
    for (const vv of toRun) {
      console.log('[ImpulseTest-v6.13] ====== RUN VARIANT ' + vv + ' ======')
      const vr = await runVariant(vv)
      result.variants.push(vr)
      console.log('[ImpulseTest-v6.13/' + vv + '] ======= RESULT =======')
      console.log(JSON.stringify(vr))
    }
    // intervalMs sweep для E
    for (const ims of sweep) {
      console.log('[ImpulseTest-v6.13] ====== RUN VARIANT E intervalMs=' + ims + ' ======')
      const vr = await runImpulseVariant(ims)
      result.variants.push(vr)
      console.log('[ImpulseTest-v6.13/E/' + ims + '] ======= RESULT =======')
      console.log(JSON.stringify(vr))
    }
    result.stage = 'done'
  } catch (e) {
    result.stage = 'error'
    result.error = String(e?.message ?? e)
  }

  window.__impulseResultV613 = result
  console.log('[ImpulseTest-v6.13] ======= ALL VARIANTS DONE =======')
  console.log(JSON.stringify(result))
  return JSON.stringify(result)
})().catch(e => {
  const err = { stage: 'error', error: String(e?.message ?? e) }
  if (window.__impulseResultV613?.errors?.length) err.errors = window.__impulseResultV613.errors
  window.__impulseResultV613 = err
  console.log('[ImpulseTest-v6.13] ======= ERROR =======')
  console.log(JSON.stringify(err))
  return JSON.stringify(err)
})